for i in */{Flute,Piccolo,Violin}.pdf
do
	cp "$i" ".Violin/`printf "$i" | sed 's_/.*\.pdf__' | sed 's_/__' `.pdf"
done

for i in */{Tuba,Euphonium}.pdf
do
	cp "$i" ".Euphonium/`printf "$i" | sed 's_/.*\.pdf__' | sed 's_/__' `.pdf"
done

for i in */Piano.pdf
do
	cp "$i" ".Piano/`printf "$i" | sed 's_/.*\.pdf__' | sed 's_/__' `.pdf"
done

for i in */Percussion.pdf
do
	cp "$i" ".Percussion/`printf "$i" | sed 's_/.*\.pdf__' | sed 's_/__' `.pdf"
done

pdfjoin .Violin/*.pdf -o Violin_book.pdf
pdfjoin .Euphonium/*.pdf -o Euphonium_book.pdf
pdfjoin .Percussion/*.pdf -o Percussion_book.pdf
pdfjoin .Piano/*.pdf -o Piano_book.pdf

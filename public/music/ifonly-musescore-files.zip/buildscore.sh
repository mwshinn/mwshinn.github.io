#for i in *.mscz
#do
#	musescore -o "`printf "$i" | sed 's_.mscz__'`.pdf" "$i" 
#done
#
cp additionals/*.pdf .
pdfjoin --pdftitle "If Only - Full Score" --pdfauthor "Max Shinn and David Stauffer" -o score.pdf *.pdf 
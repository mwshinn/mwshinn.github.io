<html>
<head>
<script type="text/javascript" src="../psychtools2/jquery-1.6.2.min.js"></script>
<script type="text/javascript" src="../psychtools2/psychtools2.js"></script>
<script type="text/javascript">

REDIRECT_URL = '../flanker2/index.php';

inst1 = new Page("inst1", false, "Instructions 1");
inst1.accept_on_keys = [KEY("{RIGHT}")];
inst1.label = "first_slide";
inst2 = new Page("inst2", false, "Instructions 2");
inst2.accept_on_keys = [KEY("{LEFT}")];
inst3 = new Page("inst3", false, "Instructions 3");
inst3.accept_on_keys = [KEY("{SPACE}")];
inst4 = new Page("inst4", false, "Instructions 4");
inst4.accept_on_keys = [KEY("{RIGHT}")];
inst4.label = "begin_practice_2";
inst5 = new Page("inst5", false, "Instructions 5");
inst5.accept_on_keys = [KEY("{LEFT}")];
inst6 = new Page("inst6", false, "Instructions 6");
inst6.accept_on_keys = [KEY("{SPACE}")];
inst7 = new Page("inst7", false, "Instructions 7");
inst7.accept_on_keys = [KEY("{SPACE}")];
inst8 = new Page("inst8", false, "Instructions 8");
inst8.accept_on_keys = [KEY("{SPACE}")];
inst9 = new Page("inst9", false, "Instructions 9");
inst9.accept_on_keys = [KEY("{SPACE}")];

pfix = new Page("pfixation", false, "Practice fixation");
pfix.time = 1000;
pshape = new Page("pshape", false, "Practice sort by shape");
pshape.time = 1000;
pcolor = new Page("pcolor", false, "Practice sort by color");
pcolor.time = 1000;


whiteboat_shape = new Page("whiteboat", true, "practice");
whiteboat_shape.time = 10000;
whiteboat_shape.accept_on_keys = [KEY("{RIGHT}"), KEY("{LEFT}")];
whiteboat_shape.correct_answer = KEY("{RIGHT}");

greenrabbit_shape = new Page("greenrabbit", true, "practice");
greenrabbit_shape.time = 10000;
greenrabbit_shape.accept_on_keys = [KEY("{RIGHT}"), KEY("{LEFT}")];
greenrabbit_shape.correct_answer = KEY("{LEFT}");

whiteboat_color = psychtools.duplicate_page(whiteboat_shape);
whiteboat_color.correct_answer = KEY("{LEFT}");
greenrabbit_color = psychtools.duplicate_page(greenrabbit_shape);
greenrabbit_color.correct_answer = KEY("{RIGHT}");


feedback = new Page("feedback", false, "Practice feedback");
feedback.save = save_slide_feedback;
feedback.load = load_slide_feedback;
feedback.accept_on_keys = [KEY("{SPACE}")];


intro = [
    inst1, inst2, inst3,
         
    pfix, pshape, whiteboat_shape, feedback,
    pfix, pshape, greenrabbit_shape, feedback,
    pfix, pshape, whiteboat_shape, feedback,
    pfix, pshape, greenrabbit_shape, feedback,
    
    inst4, inst5, inst3,
    
    pfix, pcolor, whiteboat_color, feedback,
    pfix, pcolor, greenrabbit_color, feedback,
    pfix, pcolor, whiteboat_color, feedback,
    pfix, pcolor, greenrabbit_color, feedback,
    
    inst6, inst7, inst8, inst9
];

lastpage = new Page("thanks", false, "The end"),
lastpage.label = "lastpage";
lastpage.load = load_lastpage;

isi = new Page("isi", false, "ISI");
isi.time = 800;
fixation = new Page("fixation", false, "Fixation");
fixation.time = 1000;
color = new Page("color", false, "Sort by color");
color.time = 1000;
shape = new Page("shape", false, "Sort by shape");
shape.time = 1000;

//Shape is dominant
bluetruck_color = new Page("bluetruck", true, "nondominant");
bluetruck_color.accept_on_keys = [KEY("{RIGHT}"), KEY("{LEFT}")];
bluetruck_color.time = 10000;
bluetruck_color.correct_answer = KEY("{LEFT}");

bluetruck_shape = new Page("bluetruck", true, "dominant");
bluetruck_shape.accept_on_keys = [KEY("{RIGHT}"), KEY("{LEFT}")];
bluetruck_shape.time = 10000;
bluetruck_shape.correct_answer = KEY("{RIGHT}");

yellowball_shape = new Page("yellowball", true, "dominant");
yellowball_shape.accept_on_keys = [KEY("{RIGHT}"), KEY("{LEFT}")];
yellowball_shape.time = 10000;
yellowball_shape.correct_answer = KEY("{LEFT}");

yellowball_color = new Page("yellowball", true, "nondominant");
yellowball_color.accept_on_keys = [KEY("{RIGHT}"), KEY("{LEFT}")];
yellowball_color.time = 10000;
yellowball_color.correct_answer = KEY("{RIGHT}");


cbt = [isi, fixation, color, bluetruck_color];
cyb = [isi, fixation, color, yellowball_color];
sbt = [isi, fixation, shape, bluetruck_shape];
syb = [isi, fixation, shape, yellowball_shape];

trials = [sbt, syb, syb, sbt, cbt, syb, sbt, sbt, cyb, sbt, sbt, syb, sbt, syb, cyb, sbt, syb, cbt, syb, syb, sbt, cbt, syb, sbt, syb, sbt, cyb, syb, sbt, cyb ];

//Randomize fixation time
for (l in trials.length) {
    trials[l][1].time = t[l][1].time + Math.floor(Math.random()*501);
}

//Set everything up
$(document).ready(function(){
    psychtools.initialize();
    psychtools.add_pages(intro);
    psychtools.add_trials(trials);
    psychtools.add_page(lastpage);
    psychtools.enable_autosave();
    psychtools.begin();
});


//Manage the feedback screen, and restart if they get a certain number wrong.
correct_answers = 0;
incorrect_answers = 0;
incorrect_sets = 0;
correct_sets = 0;

function load_lastpage() {
    window.location.href = REDIRECT_URL + '?id=' + psychtools._id;
}

function load_slide_feedback() {
    $('.correct, .incorrect').hide();
    if (this.prev().correct()) {
        $('.correct').show();
        correct_answers++;
    }
    else {
        $('.incorrect').show();
        if(this.prev().correct_answer == KEY("{LEFT}")) 
            $('.whiterabbit').addClass('highlighted');
        else
            $('.greenboat').addClass('highlighted');
        incorrect_answers++;
    }
}

function save_slide_feedback() {
    //Repeat if they got 2+ wrong
    $('.cardcontainercell').removeClass('highlighted');
    if (correct_answers + incorrect_answers >= 4) {
        if (incorrect_answers >= 2) {
            if (incorrect_sets > 2) 
                psychtools.override_next_page("lastpage");
            else {
                if (correct_sets == 0) 
                    psychtools.override_next_page("first_slide");
                else
                    psychtools.override_next_page("begin_practice_2");
            }
            correct_answers = 0;
            incorrect_answers = 0;
            incorrect_sets += 1;
        }
        else {
            correct_answers = 0;
            incorrect_answers = 0;
            incorrect_sets = 0; //3 incorrect at each stage, not total
            correct_sets += 1;
        }
    }
}

</script>
<link rel="stylesheet" type="text/css" href="../psychtools2/psychtools2.css" />
<link rel="stylesheet" type="text/css" href="dccs.css" />
<?php
function draw_boxes_practice() { 
?>
<table class="cardcontainers"><tr height="300px;"><td class="cardcontainersidecell"> </td><td class="cardcontainercell whiterabbit"><img src="stimuli/whiterabbit.jpg"></td><td class="cardcontainercentercell"> </td><td class="cardcontainercell greenboat"><img src="stimuli/greenboat.jpg"></td><td class="cardcontainersidecell"> </td></tr></table>
<?php 
} 
function draw_boxes() { 
?>
<table class="cardcontainers"><tr height="300px;"><td class="cardcontainercell"><img src="stimuli/blueball.jpg"></td><td class="cardcontainercentercell"> </td><td class="cardcontainercell"><img src="stimuli/yellowtruck.jpg"></td></tr></table>
<?php 
} 
?>
</head>
<body>

<div class="slide" id="slide_inst1">
<div class="content">
<div class="instructions">
You're going to play a matching game.<br />If you see the word SHAPE, select the picture that is the same SHAPE as the picture in the middle of the screen using the arrow keys.<br />If it's a Boat, press the right arrow on your keyboard.
</div>
<img src="stimuli/whiteboat.jpg">
<div class="instructions">Press the right arrow to continue</div>
<?php draw_boxes_practice(); ?>
</div>
</div>

<div class="slide" id="slide_inst2">
<div class="content">
<div class="instructions">
If it's a Rabbit, press the left arrow on your keyboard.
</div>
<img src="stimuli/greenrabbit.jpg">
<div class="instructions">Press the left arrow to continue</div>
<?php draw_boxes_practice(); ?></div>
</div>

<div class="slide" id="slide_inst3">
<div class="content">
<div class="instructions">
Now you'll have a chance to practice.<br />
Keep your eyes on the <img src="stimuli/star.jpg"> you will see in the middle of the screen.<br />
Try to answer as fast as you can without making mistakes.  If you make a mistake, just keep going.<br />
Press the space bar when you're ready to continue.
</div>
</div>
</div>

<div class="slide" id="slide_inst4">
<div class="content">
<div class="instructions">
You can also match by color.<br />If you see the word COLOR, select the picture that is the same COLOR as the picture in the middle of the screen using the arrow keys.<br />If it's a Green one, press the right arrow on your keyboard.
</div>
<img src="stimuli/greenrabbit.jpg">
<div class="instructions">Press the right arrow to continue</div>
<?php draw_boxes_practice(); ?>
</div>
</div>

<div class="slide" id="slide_inst5">
<div class="content">
<div class="instructions">
If it's a White one, press the left arrow on your keyboard.
</div>
<img src="stimuli/whiteboat.jpg">
<div class="instructions">Press the left arrow to continue</div>
<?php draw_boxes_practice(); ?></div>
</div>

<div class="slide" id="slide_inst6">
<div class="content">
<div class="instructions">
You have completed the practice.<br />Now we're going to play BOTH games together, so pay attention!!
<br />
<br />
Press the space bar to continue.
</div>
</div>
</div>

<div class="slide" id="slide_inst7">
<div class="content">
<div class="instructions">
Remember, if you see the word SHAPE, select the picture that is the same SHAPE as the picture in the middle of the screen.<br />
<br />
Press the space bar to continue.
</div>
</div>
</div>

<div class="slide" id="slide_inst8">
<div class="content">
<div class="instructions">
If you see the word COLOR, select the picture that is the same COLOR as the picture in the middle of the screen.<br />
<br />
Press the space bar to continue.
</div>
</div>
</div>

<div class="slide" id="slide_inst9">
<div class="content">
<div class="instructions">
Press the space bar to start!
</div>
</div>
</div>


<div class="slide" id="slide_isi">
<div class="content">
<div class="instructions">
</div>
<?php draw_boxes(); ?>
</div>
</div>

<div class="slide" id="slide_fixation">
<div class="content">
<div class="instructions">
<br /><br />
<img src="stimuli/star.jpg">
</div>
<?php draw_boxes(); ?>
</div>
</div>

<div class="slide" id="slide_shape">
<div class="content">
<div class="instructions">
<br /><br />
SHAPE
</div>
<?php draw_boxes(); ?>
</div>
</div>

<div class="slide" id="slide_color">
<div class="content">
<div class="instructions">
<br /><br />
COLOR
</div>
<?php draw_boxes(); ?>
</div>
</div>

<div class="slide" id="slide_pfixation">
<div class="content">
<div class="instructions">
<br /><br />
<img src="stimuli/star.jpg">
</div>
<?php draw_boxes_practice(); ?>
</div>
</div>

<div class="slide" id="slide_pshape">
<div class="content">
<div class="instructions">
<br /><br />
SHAPE
</div>
<?php draw_boxes_practice(); ?>
</div>
</div>

<div class="slide" id="slide_pcolor">
<div class="content">
<div class="instructions">
<br /><br />
COLOR
</div>
<?php draw_boxes_practice(); ?>
</div>
</div>

<div class="slide" id="slide_greenrabbit">
<div class="content">
<div class="instructions">
<img src="stimuli/greenrabbit.jpg">
</div>
<?php draw_boxes_practice(); ?>
</div>
</div>

<div class="slide" id="slide_whiteboat">
<div class="content">
<div class="instructions">
<img src="stimuli/whiteboat.jpg">
</div>
<?php draw_boxes_practice(); ?>
</div>
</div>

<div class="slide" id="slide_yellowball">
<div class="content">
<div class="instructions">
<img src="stimuli/yellowball.jpg">
</div>
<?php draw_boxes(); ?>
</div>
</div>

<div class="slide" id="slide_bluetruck">
<div class="content">
<div class="instructions">
<img src="stimuli/bluetruck.jpg">
</div>
<?php draw_boxes(); ?>
</div>
</div>

<div class="slide" id="slide_feedback">
<div class="content">
<div class="instructions">
<div style="display: none" class="correct">
Good job!  That was right!
</div>
<div style="display: none" class="incorrect">
Oops!  That was wrong!  You should have selected:
</div>
Press the space bar to continue.
</div>
<?php draw_boxes_practice(); ?>
</div>
</div>

<div class="slide" id="slide_thanks">
<div class="content">
<div class="instructions">
Thank you!  You have completed the task.  You may now close out of this browser window.
</div>
</div>
</div>

</body>
</html>

<html>
<head>
<script type="text/javascript" src="../psychtools2/jquery-1.6.2.min.js"></script>
<script type="text/javascript" src="../psychtools2/psychtools2.js"></script>
<script type="text/javascript">

REDIRECT_URL = '../questionnaire/index.php';

inst1 = new Page("inst1", false, "Instructions 1");
inst1.accept_on_keys = [KEY("{SPACE}")];
inst1.label = "first_slide";
inst2 = new Page("inst2", false, "Instructions 2");
inst2.accept_on_keys = [KEY("{RIGHT}")];
inst3 = new Page("inst3", false, "Instructions 3");
inst3.accept_on_keys = [KEY("{LEFT}")];
inst4 = new Page("inst4", false, "Instructions 4");
inst4.accept_on_keys = [KEY("{SPACE}")];
inst5 = new Page("inst5", false, "Instructions 5");
inst5.accept_on_keys = [KEY("{SPACE}")];
inst6 = new Page("inst6", false, "Instructions 6");
inst6.accept_on_keys = [KEY("{SPACE}")];

iti = new Page("iti", false, "ITI");
iti.time = 800;
fix = new Page("fix", false, "Fixation");
fix.time = 1000; //This will be set later
fix.load = add_random_fixation_time;
middle = new Page("middle", false, "Middle cue word");
middle.time = 1000
right_flankers = new Page("rightarrows", false, "Right flanking arrows");
right_flankers.time = 100;
left_flankers = new Page("leftarrows", false, "Left flanking arrows");
left_flankers.time = 100;

right_congruent = new Page("rsame", true, "congruent");
right_congruent.time = 10000;
right_congruent.accept_on_keys = [KEY("{RIGHT}"), KEY("{LEFT}")];
right_congruent.correct_answer = KEY("{RIGHT}");
right_incongruent = new Page("rdiff", true, "incongruent");
right_incongruent.time = 10000;
right_incongruent.accept_on_keys = [KEY("{RIGHT}"), KEY("{LEFT}")];
right_incongruent.correct_answer = KEY("{RIGHT}");
left_congruent = new Page("lsame", true, "congruent");
left_congruent.time = 10000;
left_congruent.accept_on_keys = [KEY("{RIGHT}"), KEY("{LEFT}")];
left_congruent.correct_answer = KEY("{LEFT}");
left_incongruent = new Page("ldiff", true, "incongruent");
left_incongruent.time = 10000;
left_incongruent.accept_on_keys = [KEY("{RIGHT}"), KEY("{LEFT}")];
left_incongruent.correct_answer = KEY("{LEFT}");

//Practice versions
left_congruent_practice = psychtools.duplicate_page(left_congruent);
left_congruent_practice.notes = "practice";
left_incongruent_practice = psychtools.duplicate_page(left_incongruent);
left_incongruent_practice.notes = "practice";
right_congruent_practice = psychtools.duplicate_page(right_congruent);
right_congruent_practice.notes = "practice";
right_incongruent_practice = psychtools.duplicate_page(right_incongruent);
right_incongruent_practice.notes = "practice";


feedback = new Page("feedback", false, "Feedback");
feedback.accept_on_keys = [KEY("{SPACE}")];
feedback.load = load_slide_feedback;
feedback.save = save_slide_feedback;

intro = [
        inst1, inst2, inst3, inst4, inst5,

        iti, fix, middle, right_flankers, right_congruent_practice, feedback,
        iti, fix, middle, left_flankers, right_incongruent_practice, feedback,
        iti, fix, middle, left_flankers, left_congruent_practice, feedback,
        iti, fix, middle, right_flankers, left_incongruent_practice, feedback,
        
        inst6
];

rc = [iti, fix, middle, right_flankers, right_congruent];
ri = [iti, fix, middle, left_flankers, right_incongruent];
lc = [iti, fix, middle, left_flankers, left_congruent];
li = [iti, fix, middle, right_flankers, left_incongruent];

trials = [lc, rc, ri, lc, ri, rc, lc, li, lc, li, rc, lc, rc, rc, li, rc, ri, lc, rc, li];

thanks = new Page("thanks", false, "The end");
thanks.label = "end";
thanks.load = load_lastpage;

$(document).ready(function(){
    psychtools.initialize();
    psychtools.add_pages(intro);
    psychtools.add_trials(trials);
    psychtools.add_page(thanks);
    psychtools.enable_autosave();
    psychtools.begin();
});


function load_lastpage() {
    window.location.href = REDIRECT_URL + '?id=' + psychtools._id;
}

function add_random_fixation_time() {
    this.time = 1000 + Math.floor(Math.random()*501);
}

correct_answers = 0;
incorrect_answers = 0;
incorrect_sets = 0;

function load_slide_feedback() {
    $('.correct, .incorrect').hide();
    if (this.prev().correct()) {
        $('.correct').show();
        correct_answers++;
    }
    else {
        $('.incorrect').show();
        if(this.prev().slide == "ldiff") 
            $('#correctimage').attr("src", "stimuli/LIC_arrows_circled.jpg");
        else if(this.prev().slide == "rdiff") 
            $('#correctimage').attr("src", "stimuli/RIC_arrows_circled.jpg");
        else if(this.prev().slide == "lsame") 
            $('#correctimage').attr("src", "stimuli/LC_arrows_circled.jpg");
        else if(this.prev().slide == "rsame") 
            $('#correctimage').attr("src", "stimuli/RC_arrows_circled.jpg");
        incorrect_answers++;
    }
}

function save_slide_feedback() {
    //Repeat if they got 2+ wrong
    $('.cardcontainercell').removeClass('highlighted');
    if (correct_answers + incorrect_answers >= 4) {
        if (incorrect_answers >= 2) {
            if (incorrect_sets > 2) 
                override_next_page("end");
            else
                override_next_page("first_slide");
            correct_answers = 0;
            incorrect_answers = 0;
            incorrect_sets += 1;
        }
    }
}

</script>
<link rel="stylesheet" type="text/css" href="../psychtools2/psychtools2.css" />
<link rel="stylesheet" type="text/css" href="flanker.css" />
</head>
<body>

<div class="slide" id="slide_inst1">
<div class="content">
<div class="instructions">
Great! Now it is time to do a different activity.  In this task, you will see a row of arrows.  You should press the button that matches the way the MIDDLE arrow is pointing.
<br />
<br />
Press the space bar to continue.<br /><br />
</div>
<img src="stimuli/RC_arrows_circled.jpg">
</div>
</div>

<div class="slide" id="slide_inst2">
<div class="content">
<div class="instructions">
If the MIDDLE arrow is facing to the right, press the right arrow key on your keyboard.
<br />
<br />
Press the right arrow key to continue.<br /><br />
</div>
<img src="stimuli/arrow_instr2_pic.jpg">
</div>
</div>

<div class="slide" id="slide_inst3">
<div class="content">
<div class="instructions">
If the MIDDLE arrow is facing to the left, press the left arrow key on your keyboard.
<br />
<br />
Press the left arrow key to continue.<br /><br />
</div>
<img src="stimuli/arrow_instr3_pic.jpg">
</div>
</div>

<div class="slide" id="slide_inst4">
<div class="content">
<div class="instructions">
Sometimes all of the arrows will point the same way.  Sometimes the MIDDLE arrow will face a different way from the others, like this:
</div>
<img src="stimuli/LICarrow_circled_pic.jpg">
<div class="instructions">
You should always press the button that matches the way the MIDDLE arrow is pointing.
<br />
<br />
Press the space bar to continue.<br /><br />
</div>
</div>
</div>

<div class="slide" id="slide_inst5">
<div class="content">
<div class="instructions">
Now you'll have a chance to practice.<br />
<li>Keep your eyes on the <img src="stimuli/star.jpg"> you will see in the middle of the screen.<br />
<li>Try to answer as fast as you can without making mistakes.  If you make a mistake, just keep going.<br /><br />

Press the space bar when you're ready to continue.
</div>
</div>
</div>

<div class="slide" id="slide_iti">
<div class="content">
 
</div>
</div>

<div class="slide" id="slide_middle">
<div class="content">
<div class="cueword">
MIDDLE
</div>
</div>
</div>

<!-- -> ->    -> -> -->
<div class="slide" id="slide_rightarrows">
<div class="content">
<div class="stimulus">
<img src="stimuli/rightflankerarrows.jpg">
</div>
</div>
</div>

<!-- <- <-    <- <- -->
<div class="slide" id="slide_leftarrows">
<div class="content">
<div class="stimulus">
<img src="stimuli/leftflankerarrows.jpg">
</div>
</div>
</div>

<!-- -> -> <- -> -> -->
<div class="slide" id="slide_ldiff">
<div class="content">
<div class="stimulus">
<img src="stimuli/RICarrows.jpg">
</div>
</div>
</div>

<!-- -> -> -> -> -> -->
<div class="slide" id="slide_rsame">
<div class="content">
<div class="stimulus">
<img src="stimuli/RCarrows.jpg">
</div>
</div>
</div>

<!-- <- <- <- <- <- -->
<div class="slide" id="slide_lsame">
<div class="content">
<div class="stimulus">
<img src="stimuli/LCarrows.jpg">
</div>
</div>
</div>

<!-- <- <- -> <- <- -->
<div class="slide" id="slide_rdiff">
<div class="content">
<div class="stimulus">
<img src="stimuli/LICarrows.jpg">
</div>
</div>
</div>

<!-- + -->
<div class="slide" id="slide_fix">
<div class="content">
<div class="stimulus">
<img src="stimuli/star.jpg">
</div>
</div>
</div>

<div class="slide" id="slide_feedback">
<div class="content">
<div class="instructions">
<div style="display: none" class="correct">
Good job!  That was right!
</div>
<div style="display: none" class="incorrect">
    Oops!  That was wrong!  You should have selected:<br /><br />
<img id="correctimage" src="" /><br />
</div>
<script type="text/javascript">
</script>
Press the space bar to continue.
</div>
</div>
</div>

<div class="slide" id="slide_inst6">
<div class="content">
<div class="instructions">
Good!  Now you're ready to play for real.  Press the space bar to start.
</div>
</div>
</div>

<div class="slide" id="slide_inst7">
<div class="content">
<div class="instructions">
Good!  Now it's time to play for real.  Remember:<br />
Keep your eyes on the <img src="stimuli/star.jpg"> you will see in the middle of the screen.<br >
Try to answer as fast as you can without making mistakes.  If you make a mistake, just keep going.<br /><br />

Press the space bar when you're ready to continue.
</div>
</div>
</div>

<div class="slide" id="slide_thanks">
<div class="content">
<div class="instructions">
Thank you!  You have completed the task.  You may now close out of this browser window.
</div>
</div>
</div>

</body>
</html>

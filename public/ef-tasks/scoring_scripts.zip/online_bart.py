#!/usr/bin/python

import csv
from math import sqrt, log

#Initialize
filename = raw_input("Filename: ")

all_values = []
reader = csv.reader(open(filename, 'rb'))
for line in reader:
    linecopy = []
    for col in line:
        if col.isdigit():
            col = int(col)
        elif col == 'NULL':
            col = None
        linecopy.append(col)
    all_values.append(linecopy)

#Defines
COL_SUBJECT = 1
COL_DATA = 2
COL_RES_SUBJECT = 0
COL_RES_TRIAL = 1
COL_RES_COLOR = 2
COL_RES_PUMPS = 3
COL_RES_TOTAL = 4

#Find all the subject ids
subjects = []
for line in all_values:
    subjects.append(str(line[COL_SUBJECT]).strip().replace("+", ""))
subjects = list(set(subjects))

def filter_matrix(matrix, colid, value):
    final = []
    if isinstance(value, type(lambda: None)) and value.__name__ == '<lambda>':
        for row in matrix:
            if value(row[colid]):
                final.append(row)
    else:
        for row in matrix:
            if row[colid] == value:
                final.append(row)
    return final

results = []
for subject_line in all_values:
    subject_trials = subject_line[COL_DATA].split("|")
    for trial in subject_trials:
        trial = trial.replace("tr:", "")
        trial = trial.replace("cl:", "")
        trial = trial.replace("lb:", "")
        trial = trial.replace("te:", "")
        trial_split = trial.split(";")
        if len(trial_split) < 3:
            continue
        results.append([str(subject_line[COL_SUBJECT]).strip().replace("+", ""), int(trial_split[0]), trial_split[1], int(trial_split[2]), int(trial_split[3])])

subject_scores = {}
for subject in subjects:
    count = 0
    for result in results:
        if result[COL_RES_SUBJECT] == subject and result[COL_RES_COLOR] == "blue" and result[COL_RES_PUMPS] != 0:
            if subject in subject_scores:
                subject_scores[subject] = int(subject_scores[subject]) + int(result[COL_RES_PUMPS])
            else:
                subject_scores[subject] = int(result[COL_RES_PUMPS])
            count += 1
    if subject in subject_scores.keys():
        print count
        subject_scores[subject] = subject_scores[subject]/float(count)

for subject_name in subject_scores.keys():
    print subject_name, "\t", subject_scores[subject_name]

#!/usr/bin/python

import csv
from math import sqrt, log
import sys

#Initialize
if len(sys.argv) > 1:
    filename = sys.argv[1]
else:
    filename = raw_input("Filename: ")
version = 2#input("Version: ")
if version == 1:
    pass
elif version == 2:
    pass
else:
    exit("Invalid version")

#Read stuff
all_values = []
reader = csv.reader(open(filename, 'rb'))
for line in reader:
    linecopy = []
    for col in line:
        if col.isdigit():
            col = int(col)
        elif col == 'NULL':
            col = None
        linecopy.append(col)
    all_values.append(linecopy)

#Defines
COL_SUBJECT = 0
COL_CORRECT = 4
COL_TIME = 2
COL_TYPE = 6
COL_SLIDE = 7

#Find all the subject ids
subjects = []
for line in all_values:
    subjects.append(line[COL_SUBJECT])
subjects = list(set(subjects))


def filter_matrix(matrix, colid, value):
    final = []
    if isinstance(value, type(lambda: None)) and value.__name__ == '<lambda>':
        for row in matrix:
            if value(row[colid]):
                final.append(row)
    else:
        for row in matrix:
            if row[colid] == value:
                final.append(row)
    return final
        
def col2array(matrix, colid):
    final = []
    for row in matrix:
        try:
            if row[colid] == None:
                continue
            final.append(row[colid])
        except:
            continue
    return final

def stdv(x):
    n, mean, std = len(x), 0, 0 
    for a in x: 
        mean = mean + a 
    mean = mean / float(n) 
    for a in x: 
        std = std + (a - mean)**2 
    std = sqrt(std / float(n-1)) 
    return std 


def mean(x):
    n, mean, std = len(x), 0, 0 
    for a in x: 
        mean = mean + a 
    mean = mean / float(n) 
    for a in x: 
        std = std + (a - mean)**2 
    std = sqrt(std / float(n-1)) 
    return std 

def truncate_high(x, high):
    final = []
    for val in x:
        if val > high:
            final.append(high)
        else:
            final.append(val)
    return final

def truncate_low(x, low):
    final = []
    for val in x:
        if val < low:
            final.append(low)
        else:
            final.append(val)
    return final



for subject in subjects:
    values = filter_matrix(all_values, COL_SUBJECT, subject)
    values = filter_matrix(values, COL_SLIDE, lambda x: x in ['bluetruck', 'yellowball'])

    if len(col2array(values, COL_CORRECT)) == 0:
        print 'no values'
        continue
    
    was_correct_list = col2array(values, COL_CORRECT)
    #Converting the t/f list into a 1/0 list
    was_correct_list_ints = []
    for item in was_correct_list:
        if item == "true":
            was_correct_list_ints.append(1)
        else:
            was_correct_list_ints.append(0)
    accuracy_score = 5.*sum(was_correct_list_ints)/len(was_correct_list_ints)
    #std_dev = stdv(col2array(values, COL_TIME))
    #mn = mean(col2array(values, COL_TIME))
    median_stuff = filter_matrix(values, COL_TIME, lambda x: x != None and x>100)
    median_stuff = filter_matrix(median_stuff, COL_TIME, lambda x: x != None and x<10000)
    median_stuff = filter_matrix(median_stuff, COL_TYPE, "nondominant")
    #median_stuff = filter_matrix(median_stuff, COL_TIME, lambda x: x != None and abs(x)-abs(mn) <= abs(std_dev*3))
    median_stuff = col2array(median_stuff, COL_TIME)
    median_stuff = truncate_high(median_stuff, 3000)
    median_stuff = truncate_low(median_stuff, 300)
    try:
        if len(median_stuff) == 0:
            median = 3000
        elif len(median_stuff) % 2 == 1:
            index = (len(median_stuff)-1)/2
            median = median_stuff[index]
        else:
            index = len(median_stuff)/2
            median = (median_stuff[index-1] + median_stuff[index])/2
        time_score = 5 - (5*(log(median)-log(300))/(log(3000)-log(300)))

        #that last part I forgot about...
        if accuracy_score < 4:
            time_score = 0
        print "Subject {0}, total: {1}, time-score: {2}, accuracy-score: {3} ".format(subject, round(time_score+accuracy_score, 2), round(time_score, 2), round(accuracy_score, 2))
    except IndexError:
        time_score = "Error"
        print len(median_stuff)
        print "Subject {0}, total: none, time-score: {1}, accuracy-score: {2} ".format(subject, time_score, round(accuracy_score, 2))



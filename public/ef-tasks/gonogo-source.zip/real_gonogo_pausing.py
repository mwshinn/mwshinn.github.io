#!/usr/bin/python
#My 4th implementation of a pausable go/no-go.  Here we go...

import pygame
from pygame.locals import *

import random
from os import path, unlink

if not pygame.font: 
    print "Error, no fonts available"
if not pygame.mixer: 
    print "Error, no sounds available"

#Defines
DATA_OUTPUT_FILENAME = "data.csv"

SCREEN_X = 1024
SCREEN_Y = 768

GO_IMAGE = "cheese.jpg"
NOGO_IMAGE = "cat.jpg"

PRACTICE_STIM_DURATION = 1500
FIXATION_DURATION = 1000
STIM_DURATION = 1000
ITI_DURATION = 1000

PRACTICE_TRIALS = 4
PRACTICE_CORRECT_PERCENT = .75
MAX_PRACTICE_BLOCKS = 3

TRIALS = 20*3*60 #This needs to be an even number or bad things could happen


#System defines
white = pygame.Color("white")
black = pygame.Color("black")


#Classes

"""
The Logger class will dynamically log any variable.  Just create it,
and then pass the stuff as named arguments to log to the log()
function.  This will use argument names as keys.
"""
class Logger:
    def __init__(self, **always_log):
        self._log = []
        self._always_log = always_log
        if self.test_file_output(DATA_OUTPUT_FILENAME+".tmp") == False:
            exit("Cannot write to target file.  Exiting now to avoid lost data.  Check the file and directory permissions, and see if the disk is full.")
    
    def log(self, *args, **kwargs):
        kwargs.update(self._always_log)
        self._log.append(kwargs)

    def format_log(self):
        logged_kws = []
        sorted_log = []
        #Find all of the keywords in all calls to log()
        for i in range(0, len(self._log)):
            for kw in self._log[i]:
                if not kw in logged_kws:
                    logged_kws.append(kw)
        #Iterate through each keyword and find each call to log() that
        #included that keyword
        for kw in logged_kws:
            kw_items = []
            for i in range(0,len(self._log)):
                if kw in self._log[i]:
                    kw_items.append(str(self._log[i][kw]))
                else:
                    kw_items.append("")
        #Now save it to a string
        formatted_log = ""
        d = ","
        #Header row
        formatted_log += d.join(logged_kws) + "\n"
        for i in range(0,len(self._log)):
            row = []
            for kw in logged_kws:
                if kw in self._log[i]:
                    row.append(str(self._log[i][kw]))
                else:
                    row.append("")
            formatted_log += ",".join(row) + "\n"
        return formatted_log

    def write_to_file(self, filename):
        file = open(filename, 'a+')
        file.write(self.format_log())
        file.close()
        
    def test_file_output(self, filename):
        try:
            self.write_to_file(filename)
        except IOError:
            return False
        if not path.isfile(filename):
            return False
        unlink(filename)
        return True

#Functions 

#Returns once the space key is pressed
def wait_for_space():
    while True:
        e = pygame.event.wait()
        if e.type == KEYUP and e.key == K_SPACE:
            return

#Returns a Surface
def load_image(name):
    tmp = pygame.image.load(name)
    #return tmp.convert()
    return tmp

#Does one trial.  Returns True if the response was correct, and false if it wasn't.
def trial(go, practice=False):
    #Fixation
    screen.fill(black)
    pygame.draw.line(screen, white, (SCREEN_X/2+5, SCREEN_Y/2), (SCREEN_X/2-5, SCREEN_Y/2))
    pygame.draw.line(screen, white, (SCREEN_X/2, SCREEN_Y/2+5), (SCREEN_X/2, SCREEN_Y/2-5))
    pygame.display.flip()
    pygame.time.delay(FIXATION_DURATION)

    #Stimulus
    screen.fill(black)
    if go:
        screen.blit(go_img, (SCREEN_X/2-go_img.get_width()/2, SCREEN_Y/2-go_img.get_height()/2))
    else:
        screen.blit(nogo_img, (SCREEN_X/2-nogo_img.get_width()/2, SCREEN_Y/2-nogo_img.get_height()/2))
    responded = False
    start_time = pygame.time.get_ticks()
    stop_time = 0
    pygame.display.flip()
    #Record the keypress
    if practice:
        sduration = PRACTICE_STIM_DURATION
    else:
        sduration = STIM_DURATION
    while pygame.time.get_ticks() <= start_time + sduration:
        for e in pygame.event.get(KEYDOWN):
            if e.key == K_SPACE:
                stop_time = pygame.time.get_ticks()
                responded = True
                break
            elif e.key == K_RETURN: #Checking for pause
                pause()
                return False
    if stop_time == 0:
        rt = 0
    else:
        rt = stop_time-start_time
    logger.log(correct=(responded==go), rt=rt, practice=practice)
    
    #ITI
    if not practice:
        screen.fill(black)
        pygame.display.flip()
        pygame.time.delay(ITI_DURATION)

    #Was it correct?
    return responded == go
    
def pause():
    print "paused"
    #Draw the pause screen
    start_time = pygame.time.get_ticks()
    pygame.event.clear()
    screen.fill(black)
    screen.blit(pause_img, pause_img.get_rect())
    pygame.display.flip()
    #Wait for unpause
    exit = False
    while not exit:
        for e2 in pygame.event.get(KEYDOWN):
            if e2.key == K_RETURN:
                exit = True
    stop_time = pygame.time.get_ticks()
    logger.log(paused=True, pause_time=(stop_time-start_time))
    pygame.event.clear()


#Displays the designated image on the screen and waits for the space bar
def show_screen(image):
    pygame.event.clear()
    screen.fill(black)
    screen.blit(image, image.get_rect())
    pygame.display.flip()
    wait_for_space()


participant_id = input("Participant ID: ")
session_number = input("Session number: ")
pygame.init()
screen = pygame.display.set_mode((SCREEN_X, SCREEN_Y))
logger = Logger(id=participant_id, session=session_number)

#Img resources
instr1 = load_image("text1.png")
instr2 = load_image("text2.png")
instr3 = load_image("text3.png")
instr4 = load_image("text4.png")
go_img = load_image(GO_IMAGE)
nogo_img = load_image(NOGO_IMAGE)
correct_img = load_image("correct.png")
incorrect_go_img = load_image("incorrect_go.png")
incorrect_nogo_img = load_image("incorrect_nogo.png")
pause_img = load_image("pause.png")

#Instructions
show_screen(instr1)
show_screen(instr2)



#Practice
for i in range(1,MAX_PRACTICE_BLOCKS+1):
    total = 0
    for type in [False, True, False, True]:
        #Show it
        result = trial(type, practice=True)
        total += int(result)
        #Feedback
        if result == True:
            show_screen(correct_img)
        elif type == False:
            show_screen(incorrect_nogo_img)
        else:
            show_screen(incorrect_go_img)
    #Continue if they made the theshold
    if total >= PRACTICE_CORRECT_PERCENT * PRACTICE_TRIALS:
        break
    #Fail!
    if i == MAX_PRACTICE_BLOCKS:
        pass #TODO Implement this


#The real deal
show_screen(instr3)

trials = []
#Order the trials randomly
for i in range(1,TRIALS/2+1):
    trials.append(True)
    trials.append(False)
random.shuffle(trials)

for type in trials:
    trial(type)
    events = pygame.event.get(KEYDOWN)
    for e in events:
        if e.key == K_RETURN:
            pause()
            

show_screen(instr4)

print logger.format_log()
logger.write_to_file("study_test_output.csv")

<html>
<head>
<script type="text/javascript" src="../psychtools/jquery-1.6.2.min.js"></script>
<script type="text/javascript" src="../psychtools/psychtools.js"></script>
<script type="text/javascript">
data = [
        ["inst1", [32], "Instructions 1", 0, null, 0, null],
        ["inst2", [32], "Instructions 2", 0, null, 0, null],
        ["inst3", [32], "Instructions 3", 0, null, 0, null],
        ["inst4", [32], "Instructions 4", 0, null, 0, null],
        ["inst5", [32], "Instructions 5", 0, null, 0, null],
        ["inst6", [39], "Instructions 6", 0, null, 0, null],
        ["inst7", [37], "Instructions 7", 0, null, 0, null],
        ["inst8", [32], "Instructions 8", 0, null, 0, null],
        ["inst9", [39], "Instructions 9", 0, null, 0, null],
        ["inst10", [37], "Instructions 10", 0, null, 0, null],
        ["inst11", [32], "Instructions 11", 0, null, 0, null],
        ["iti", -1, "iti", 0, 800, 0, null],
        ["fix", -1, "fixation", 0, 1000 + Math.floor(Math.random()*501), 0, null],
        ["middle", -1, "middle cue", 0, 1000, 0, null],
        ["rightfish", -1, "flankers", 0, 100, 0, null],
        ["frsame", [37, 39], "practice", 1, 10000, 1, 39],
        ["feedback", [32], "Feedback page", 0, null, 0, null],
        ["iti", -1, "iti", 0, 800, 0, null],
        ["fix", -1, "fixation", 0, 1000 + Math.floor(Math.random()*501), 0, null],
        ["middle", -1, "middle cue", 0, 1000, 0, null],
        ["leftfish", -1, "flankers", 0, 100, 0, null],
        ["frdiff", [37, 39], "practice", 1, 10000, 1, 39],
        ["feedback", [32], "Feedback page", 0, null, 0, null],
        ["iti", -1, "iti", 0, 800, 0, null],
        ["fix", -1, "fixation", 0, 1000 + Math.floor(Math.random()*501), 0, null],
        ["middle", -1, "middle cue", 0, 1000, 0, null],
        ["leftfish", -1, "flankers", 0, 100, 0, null],
        ["flsame", [37, 39], "practice", 1, 10000, 1, 37],
        ["feedback", [32], "Feedback page", 0, null, 0, null],
        ["iti", -1, "iti", 0, 800, 0, null],
        ["fix", -1, "fixation", 0, 1000 + Math.floor(Math.random()*501), 0, null],
        ["middle", -1, "middle cue", 0, 1000, 0, null],
        ["rightfish", -1, "flankers", 0, 100, 0, null],
        ["fldiff", [37, 39], "practice", 1, 10000, 1, 37],
        ["feedback", [32], "Feedback page", 0, null, 0, null],


        ["inst12", [32], "Instructions 6", 0, null, 0, null],
        ["inst9", [39], "Instructions 6", 0, null, 0, null],
        ["inst10", [37], "Instructions 7", 0, null, 0, null],
        ["inst13", [32], "Instructions 6", 0, null, 0, null],

        ["iti", -1, "iti", 0, 800, 0, null],
        ["fix", -1, "fixation", 0, 1000 + Math.floor(Math.random()*501), 0, null],
        ["middle", -1, "middle cue", 0, 1000, 0, null],
        ["leftfish", -1, "flankers", 0, 100, 0, null],
        ["flsame", [37, 39], "congruent", 1, 10000, 1, 37],
        ["iti", -1, "iti", 0, 800, 0, null],
        ["fix", -1, "fixation", 0, 1000 + Math.floor(Math.random()*501), 0, null],
        ["middle", -1, "middle cue", 0, 1000, 0, null],
        ["rightfish", -1, "flankers", 0, 100, 0, null],
        ["frsame", [37, 39], "congruent", 1, 10000, 1, 39],
        ["iti", -1, "iti", 0, 800, 0, null],
        ["fix", -1, "fixation", 0, 1000 + Math.floor(Math.random()*501), 0, null],
        ["middle", -1, "middle cue", 0, 1000, 0, null],
        ["leftfish", -1, "flankers", 0, 100, 0, null],
        ["frdiff", [37, 39], "incongruent", 1, 10000, 1, 39],
        ["iti", -1, "iti", 0, 800, 0, null],
        ["fix", -1, "fixation", 0, 1000 + Math.floor(Math.random()*501), 0, null],
        ["middle", -1, "middle cue", 0, 1000, 0, null],
        ["leftfish", -1, "flankers", 0, 100, 0, null],
        ["flsame", [37, 39], "congruent", 1, 10000, 1, 37],
        ["iti", -1, "iti", 0, 800, 0, null],
        ["fix", -1, "fixation", 0, 1000 + Math.floor(Math.random()*501), 0, null],
        ["middle", -1, "middle cue", 0, 1000, 0, null],
        ["leftfish", -1, "flankers", 0, 100, 0, null],
        ["frdiff", [37, 39], "incongruent", 1, 10000, 1, 39],
        ["iti", -1, "iti", 0, 800, 0, null],
        ["fix", -1, "fixation", 0, 1000 + Math.floor(Math.random()*501), 0, null],
        ["middle", -1, "middle cue", 0, 1000, 0, null],
        ["rightfish", -1, "flankers", 0, 100, 0, null],
        ["frsame", [37, 39], "congruent", 1, 10000, 1, 39],
        ["iti", -1, "iti", 0, 800, 0, null],
        ["fix", -1, "fixation", 0, 1000 + Math.floor(Math.random()*501), 0, null],
        ["middle", -1, "middle cue", 0, 1000, 0, null],
        ["leftfish", -1, "flankers", 0, 100, 0, null],
        ["flsame", [37, 39], "congruent", 1, 10000, 1, 37],
        ["iti", -1, "iti", 0, 800, 0, null],
        ["fix", -1, "fixation", 0, 1000 + Math.floor(Math.random()*501), 0, null],
        ["middle", -1, "middle cue", 0, 1000, 0, null],
        ["rightfish", -1, "flankers", 0, 100, 0, null],
        ["fldiff", [37, 39], "incongruent", 1, 10000, 1, 37],
        ["iti", -1, "iti", 0, 800, 0, null],
        ["fix", -1, "fixation", 0, 1000 + Math.floor(Math.random()*501), 0, null],
        ["middle", -1, "middle cue", 0, 1000, 0, null],
        ["leftfish", -1, "flankers", 0, 100, 0, null],
        ["flsame", [37, 39], "congruent", 1, 10000, 1, 37],
        ["iti", -1, "iti", 0, 800, 0, null],
        ["fix", -1, "fixation", 0, 1000 + Math.floor(Math.random()*501), 0, null],
        ["middle", -1, "middle cue", 0, 1000, 0, null],
        ["rightfish", -1, "flankers", 0, 100, 0, null],
        ["fldiff", [37, 39], "incongruent", 1, 10000, 1, 37],
        ["iti", -1, "iti", 0, 800, 0, null],
        ["fix", -1, "fixation", 0, 1000 + Math.floor(Math.random()*501), 0, null],
        ["middle", -1, "middle cue", 0, 1000, 0, null],
        ["rightfish", -1, "flankers", 0, 100, 0, null],
        ["frsame", [37, 39], "congruent", 1, 10000, 1, 39],
        ["iti", -1, "iti", 0, 800, 0, null],
        ["fix", -1, "fixation", 0, 1000 + Math.floor(Math.random()*501), 0, null],
        ["middle", -1, "middle cue", 0, 1000, 0, null],
        ["leftfish", -1, "flankers", 0, 100, 0, null],
        ["flsame", [37, 39], "congruent", 1, 10000, 1, 37],
        ["iti", -1, "iti", 0, 800, 0, null],
        ["fix", -1, "fixation", 0, 1000 + Math.floor(Math.random()*501), 0, null],
        ["middle", -1, "middle cue", 0, 1000, 0, null],
        ["rightfish", -1, "flankers", 0, 100, 0, null],
        ["frsame", [37, 39], "congruent", 1, 10000, 1, 39],
        ["iti", -1, "iti", 0, 800, 0, null],
        ["fix", -1, "fixation", 0, 1000 + Math.floor(Math.random()*501), 0, null],
        ["middle", -1, "middle cue", 0, 1000, 0, null],
        ["rightfish", -1, "flankers", 0, 100, 0, null],
        ["frsame", [37, 39], "congruent", 1, 10000, 1, 39],
        ["iti", -1, "iti", 0, 800, 0, null],
        ["fix", -1, "fixation", 0, 1000 + Math.floor(Math.random()*501), 0, null],
        ["middle", -1, "middle cue", 0, 1000, 0, null],
        ["rightfish", -1, "flankers", 0, 100, 0, null],
        ["fldiff", [37, 39], "incongruent", 1, 10000, 1, 37],
        ["iti", -1, "iti", 0, 800, 0, null],
        ["fix", -1, "fixation", 0, 1000 + Math.floor(Math.random()*501), 0, null],
        ["middle", -1, "middle cue", 0, 1000, 0, null],
        ["rightfish", -1, "flankers", 0, 100, 0, null],
        ["frsame", [37, 39], "congruent", 1, 10000, 1, 39],
        ["iti", -1, "iti", 0, 800, 0, null],
        ["fix", -1, "fixation", 0, 1000 + Math.floor(Math.random()*501), 0, null],
        ["middle", -1, "middle cue", 0, 1000, 0, null],
        ["leftfish", -1, "flankers", 0, 100, 0, null],
        ["frdiff", [37, 39], "incongruent", 1, 10000, 1, 39],
        ["iti", -1, "iti", 0, 800, 0, null],
        ["fix", -1, "fixation", 0, 1000 + Math.floor(Math.random()*501), 0, null],
        ["middle", -1, "middle cue", 0, 1000, 0, null],
        ["leftfish", -1, "flankers", 0, 100, 0, null],
        ["flsame", [37, 39], "congruent", 1, 10000, 1, 37],
        ["iti", -1, "iti", 0, 800, 0, null],
        ["fix", -1, "fixation", 0, 1000 + Math.floor(Math.random()*501), 0, null],
        ["middle", -1, "middle cue", 0, 1000, 0, null],
        ["rightfish", -1, "flankers", 0, 100, 0, null],
        ["frsame", [37, 39], "congruent", 1, 10000, 1, 39],
        ["iti", -1, "iti", 0, 800, 0, null],
        ["fix", -1, "fixation", 0, 1000 + Math.floor(Math.random()*501), 0, null],
        ["middle", -1, "middle cue", 0, 1000, 0, null],
        ["rightfish", -1, "flankers", 0, 100, 0, null],
        ["fldiff", [37, 39], "incongruent", 1, 10000, 1, 37],
        ["thanks", null, "Thanks", 0, null, 0, null]
];

add_pages(data);
 

correct_answers = 0;
incorrect_answers = 0;
incorrect_sets = 0;

function load_slide_feedback(i, data, data_log) {
    if (data_log.length == 0)
        return;
    $('.correct, .incorrect').hide();
    if (data_log[data_log.length-1][RESULTS_CORRECT] == true) {
        $('.correct').show();
        correct_answers++;
    }
    else {
        $('.incorrect').show();
        if(data[i-1][PAGE_SLIDE] == "fldiff") 
            $('#correctimage').attr("src", "stimuli/leftkey.jpg");
        else if(data[i-1][PAGE_SLIDE] == "frdiff") 
            $('#correctimage').attr("src", "stimuli/rightkey.jpg");
        else if(data[i-1][PAGE_SLIDE] == "flsame") 
            $('#correctimage').attr("src", "stimuli/leftkey.jpg");
        else if(data[i-1][PAGE_SLIDE] == "frsame") 
            $('#correctimage').attr("src", "stimuli/rightkey.jpg");
        incorrect_answers++;
    }
}

function save_slide_feedback(i, data, data_log) {
    //Repeat if they got 2+ wrong
    $('.cardcontainercell').removeClass('highlighted');
    if (correct_answers + incorrect_answers >= 4) {
        if (incorrect_answers >= 2) {
            if (incorrect_sets > 2) 
                override_next_page(data.length-1);
            else
                override_next_page(0);
            correct_answers = 0;
            incorrect_answers = 0;
            incorrect_sets += 1;
        }
    }
}

//Send the log periodically
function load_slide_iti() {
    send_log();
}

//function data_sent(data) {
//    $('.sending-data').hide();
//    $('.data-sent').show();
//}
</script>
<link rel="stylesheet" type="text/css" href="../psychtools/psychtools.css" />
<link rel="stylesheet" type="text/css" href="flanker.css" />
</head>
<body>

<div class="slide" id="slide_inst1">
<div class="content">
<div class="instructions">
Here is a fish!<br /><br />

This is the tail &rarr; <img src="stimuli/RightFish.jpg" class="inlineimages"> &larr; This is the mouth
<br />
<br />
The fish is pointing the same way the mouth is pointing.
<br /><br />
Press the space bar to continue.
</div>
</div>
</div>

<div class="slide" id="slide_inst2">
<div class="content">
<div class="instructions">
Here is the middle fish.  Can you point to the middle fish?
<br />
<br />
</div>
<img src="stimuli/RightFish.jpg"><img src="stimuli/RightFish.jpg"><img src="stimuli/RightCircledFish.jpg"><img src="stimuli/RightFish.jpg"><img src="stimuli/RightFish.jpg">
<div class="instructions">
<br /><br />Press the space bar to continue.
</div>
</div>
</div>

<div class="slide" id="slide_inst3">
<div class="content">
<div class="instructions">
Where is the middle fish here?
<br />
<br />
</div>
<img src="stimuli/LeftFish.jpg"><img src="stimuli/LeftFish.jpg"><img src="stimuli/LeftFish.jpg"><img src="stimuli/LeftFish.jpg"><img src="stimuli/LeftFish.jpg">
<div class="instructions">
<br /><br />Press the space bar to continue.
</div>
</div>
</div>

<div class="slide" id="slide_inst4">
<div class="content">
<div class="instructions">
Look at all the fish!  The fish in the MIDDLE is hungry.
<br />
<br />
</div>
<img src="stimuli/RightFish.jpg"><img src="stimuli/RightFish.jpg"><img src="stimuli/RightCircledFish.jpg"><img src="stimuli/RightFish.jpg"><img src="stimuli/RightFish.jpg">
<div class="instructions">
<br /><br />Press the space bar to continue.
</div>

</div>
</div>

<div class="slide" id="slide_inst5">
<div class="content">
<div class="instructions">
To feed the MIDDLE fish, press the button that matches the way the MIDDLE fish is pointing.
<br />
<br />
</div>
<img src="stimuli/RightFish.jpg"><img src="stimuli/RightFish.jpg"><img src="stimuli/RightCircledFish.jpg"><img src="stimuli/RightFish.jpg"><img src="stimuli/RightFish.jpg">
<div class="instructions">
<br /><br />Press the space bar to continue.
</div>
</div>
</div>

<div class="slide" id="slide_inst6">
<div class="content">
<div class="instructions">
If the middle fish is pointing this way, press this button.
<br />
<br />
</div>
<img src="stimuli/RightFish.jpg"><img src="stimuli/RightFish.jpg"><img src="stimuli/RightCircledFish.jpg"><img src="stimuli/RightFish.jpg"><img src="stimuli/RightFish.jpg">
<div class="instructions">
<br /><br />Press the right arrow to continue.
</div>
</div>
</div>

<div class="slide" id="slide_inst7">
<div class="content">
<div class="instructions">
If the middle fish is pointing this way, press this button.
<br />
<br />
</div>
<img src="stimuli/LeftFish.jpg"><img src="stimuli/LeftFish.jpg"><img src="stimuli/LeftCircledFish.jpg"><img src="stimuli/LeftFish.jpg"><img src="stimuli/LeftFish.jpg">
<div class="instructions">
<br /><br />Press the left arrow to continue.
</div>
</div>
</div>

<div class="slide" id="slide_inst8">
<div class="content">
<div class="instructions">
Sometimes all the fish will point the same way.  Sometimes, the MIDDLE fish will point a different way from his friends, like this:
</div>
<img src="stimuli/LeftFish.jpg"><img src="stimuli/LeftFish.jpg"><img src="stimuli/RightCircledFish.jpg"><img src="stimuli/LeftFish.jpg"><img src="stimuli/LeftFish.jpg">
<div class="instructions">
You should always press the button that matches the way the MIDDLE fish is pointing.  You will see the word MIDDLE to remind you.
<br />
<br />
Press the space bar to continue.<br /><br />
</div>
</div>
</div>

<div class="slide" id="slide_inst9">
<div class="content">
<div class="instructions">
Here the MIDDLE fish is pointing this way, so I'll press this button.
<br />
<br />
</div>
<img src="stimuli/RightFish.jpg"><img src="stimuli/RightFish.jpg"><img src="stimuli/RightFish.jpg"><img src="stimuli/RightFish.jpg"><img src="stimuli/RightFish.jpg">
<div class="instructions">
<br /><br />Press the right arrow to continue.
</div>
</div>
</div>

<div class="slide" id="slide_inst10">
<div class="content">
<div class="instructions">
Here the MIDDLE fish is pointing this way, so I'll press this button.
<br />
<br />
</div>
<img src="stimuli/RightFish.jpg"><img src="stimuli/RightFish.jpg"><img src="stimuli/LeftFish.jpg"><img src="stimuli/RightFish.jpg"><img src="stimuli/RightFish.jpg">
<div class="instructions">
<br /><br />Press the left arrow to continue.
</div>
</div>
</div>

<div class="slide" id="slide_inst11">
<div class="content">
<div class="instructions">
Now you'll have a chance to practice.<br />
<li>Keep your eyes on the <img src="stimuli/star.jpg"> you will see in the middle of the screen.<br />
<li>Try to answer as fast as you can without making mistakes.  If you make a mistake, just keep going.<br /><br />

Press the space bar when you're ready to continue.
</div>
</div>
</div>

<div class="slide" id="slide_iti">
<div class="content">
 
</div>
</div>

<div class="slide" id="slide_middle">
<div class="content">
<div class="cueword">
MIDDLE
</div>
</div>
</div>

<!-- -> ->    -> -> -->
<div class="slide" id="slide_rightarrows">
<div class="content">
<div class="stimulus">
<img src="stimuli/rightflankerarrows.jpg">
</div>
</div>
</div>

<!-- <- <-    <- <- -->
<div class="slide" id="slide_leftarrows">
<div class="content">
<div class="stimulus">
<img src="stimuli/leftflankerarrows.jpg">
</div>
</div>
</div>

<!-- -> -> <- -> -> -->
<div class="slide" id="slide_ldiff">
<div class="content">
<div class="stimulus">
<img src="stimuli/RICarrows.jpg">
</div>
</div>
</div>

<!-- -> -> -> -> -> -->
<div class="slide" id="slide_rsame">
<div class="content">
<div class="stimulus">
<img src="stimuli/RCarrows.jpg">
</div>
</div>
</div>

<!-- <- <- <- <- <- -->
<div class="slide" id="slide_lsame">
<div class="content">
<div class="stimulus">
<img src="stimuli/LCarrows.jpg">
</div>
</div>
</div>

<!-- <- <- -> <- <- -->
<div class="slide" id="slide_rdiff">
<div class="content">
<div class="stimulus">
<img src="stimuli/LICarrows.jpg">
</div>
</div>
</div>

<!-- + -->
<div class="slide" id="slide_fix">
<div class="content">
<div class="stimulus">
<img src="stimuli/star.jpg">
</div>
</div>
</div>

<div class="slide" id="slide_rightfish">
<div class="content">
<div class="stimulus">
<img src="stimuli/RightFish.jpg"><img src="stimuli/RightFish.jpg"><img src="stimuli/NoFish.jpg"><img src="stimuli/RightFish.jpg"><img src="stimuli/RightFish.jpg">
</div>
</div>
</div>

<div class="slide" id="slide_leftfish">
<div class="content">
<div class="stimulus">
<img src="stimuli/LeftFish.jpg"><img src="stimuli/LeftFish.jpg"><img src="stimuli/NoFish.jpg"><img src="stimuli/LeftFish.jpg"><img src="stimuli/LeftFish.jpg">
</div>
</div>
</div>

<div class="slide" id="slide_flsame">
<div class="content">
<div class="stimulus">
<img src="stimuli/LeftFish.jpg"><img src="stimuli/LeftFish.jpg"><img src="stimuli/LeftFish.jpg"><img src="stimuli/LeftFish.jpg"><img src="stimuli/LeftFish.jpg">
</div>
</div>
</div>

<div class="slide" id="slide_frdiff">
<div class="content">
<div class="stimulus">
<img src="stimuli/LeftFish.jpg"><img src="stimuli/LeftFish.jpg"><img src="stimuli/RightFish.jpg"><img src="stimuli/LeftFish.jpg"><img src="stimuli/LeftFish.jpg">
</div>
</div>
</div>

<div class="slide" id="slide_frsame">
<div class="content">
<div class="stimulus">
<img src="stimuli/RightFish.jpg"><img src="stimuli/RightFish.jpg"><img src="stimuli/RightFish.jpg"><img src="stimuli/RightFish.jpg"><img src="stimuli/RightFish.jpg">
</div>
</div>
</div>

<div class="slide" id="slide_fldiff">
<div class="content">
<div class="stimulus">
<img src="stimuli/RightFish.jpg"><img src="stimuli/RightFish.jpg"><img src="stimuli/LeftFish.jpg"><img src="stimuli/RightFish.jpg"><img src="stimuli/RightFish.jpg">
</div>
</div>
</div>

<div class="slide" id="slide_feedback">
<div class="content">
<div class="instructions">
<div style="display: none" class="correct">
Good job!  That was right!
</div>
<div style="display: none" class="incorrect">
    Oops!  That was wrong!  You should have pressed:<br /><br />
<img id="correctimage" src="" /><br />
</div>
<script type="text/javascript">
</script>
<br />Press the space bar to continue.
</div>
</div>
</div>

<div class="slide" id="slide_inst12">
<div class="content">
<div class="instructions">
Good!  Now you're ready to play for real.  Press the space bar to continue.
</div>
</div>
</div>

<div class="slide" id="slide_inst13">
<div class="content">
<div class="instructions">
Good!  Now it's time to play for real.  Remember:<br />
Keep your eyes on the <img src="stimuli/star.jpg"> you will see in the middle of the screen.<br >
Try to answer as fast as you can without making mistakes.  If you make a mistake, just keep going.<br /><br />

Press the space bar when you're ready to continue.
</div>
</div>
</div>

<div class="slide" id="slide_thanks">
<div class="content">
<div class="instructions">
Thank you!  You have completed the task.  You may now close out of this browser window.
</div>
</div>
</div>

</body>
</html>

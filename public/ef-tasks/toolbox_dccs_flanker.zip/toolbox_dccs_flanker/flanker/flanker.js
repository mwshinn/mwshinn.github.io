SUBMIT_URL = "log.php";

//Slide order format
SLIDE_ID = 0;
ACCEPT_KEY = 1;
NOTES =  2;
SAVE_LATENCY = 3;
TIME = 4;
SAVE_DATA = 5;
CORRECT = 6;
DISPLAY_IF = 7;

//Data results format
INDEX = 0;
LATENCY = 1;
KEY_PRESSED = 2;
WAS_CORRECT = 3;
CORRECT_ANSWER = 4;
NOTES = 5;
PAGE_ID = 6;

data = [
        ["name", [13], "Enter your name", 0, null, 0, null],
        ["inst1", null, "Instructions 1", 0, null, 0, null],
        ["inst2", null, "Instructions 2", 0, null, 0, null],
        ["inst3", null, "Instructions 3", 0, null, 0, null],
        ["inst4", null, "Instructions 4", 0, null, 0, null],
        ["inst5", null, "Instructions 5", 0, null, 0, null],
        ["fix", -1, "fixation", 0, 1000, 0, null],
        ["rsame", [37, 39], "practice trial 1", 1, null, 1, 39],
        ["feedback", null, "Feedback page", 0, null, 0, null],
        ["fix", -1, "fixation", 0, 1000, 0, null],
        ["rdiff", [37, 39], "practice trial 2", 1, null, 1, 39],
        ["feedback", null, "Feedback page", 0, null, 0, null],
        ["fix", -1, "fixation", 0, 1000, 0, null],
        ["lsame", [37, 39], "practice trial 3", 1, null, 1, 37],
        ["feedback", null, "Feedback page", 0, null, 0, null],
        ["fix", -1, "fixation", 0, 1000, 0, null],
        ["ldiff", [37, 39], "practice trial 4", 1, null, 1, 37],
        ["feedback", null, "Feedback page", 0, null, 0, null],
        ["inst6", null, "Instructions 6", 0, null, 0, null],

        ["fix", -1, "fixation", 0, 1000, 0, null],
        ["lsame", [37, 39], "practice trial 4", 1, null, 1, 37],
        ["fix", -1, "fixation", 0, 1000, 0, null],
        ["rsame", [37, 39], "practice trial 4", 1, null, 1, 39],
        ["fix", -1, "fixation", 0, 1000, 0, null],
        ["rdiff", [37, 39], "practice trial 2", 1, null, 1, 39],
        ["fix", -1, "fixation", 0, 1000, 0, null],
        ["lsame", [37, 39], "practice trial 4", 1, null, 1, 37],
        ["fix", -1, "fixation", 0, 1000, 0, null],
        ["rdiff", [37, 39], "practice trial 2", 1, null, 1, 39],
        ["fix", -1, "fixation", 0, 1000, 0, null],
        ["rsame", [37, 39], "practice trial 4", 1, null, 1, 39],
        ["fix", -1, "fixation", 0, 1000, 0, null],
        ["lsame", [37, 39], "practice trial 4", 1, null, 1, 37],
        ["fix", -1, "fixation", 0, 1000, 0, null],
        ["ldiff", [37, 39], "practice trial 4", 1, null, 1, 37],
        ["fix", -1, "fixation", 0, 1000, 0, null],
        ["lsame", [37, 39], "practice trial 4", 1, null, 1, 37],
        ["fix", -1, "fixation", 0, 1000, 0, null],
        ["ldiff", [37, 39], "practice trial 4", 1, null, 1, 37],
        ["fix", -1, "fixation", 0, 1000, 0, null],
        ["rsame", [37, 39], "practice trial 4", 1, null, 1, 39],
        ["fix", -1, "fixation", 0, 1000, 0, null],
        ["lsame", [37, 39], "practice trial 4", 1, null, 1, 37],
        ["fix", -1, "fixation", 0, 1000, 0, null],
        ["rsame", [37, 39], "practice trial 4", 1, null, 1, 39],
        ["fix", -1, "fixation", 0, 1000, 0, null],
        ["rsame", [37, 39], "practice trial 4", 1, null, 1, 39],
        ["fix", -1, "fixation", 0, 1000, 0, null],
        ["ldiff", [37, 39], "practice trial 4", 1, null, 1, 37],
        ["fix", -1, "fixation", 0, 1000, 0, null],
        ["rsame", [37, 39], "practice trial 4", 1, null, 1, 39],
        ["fix", -1, "fixation", 0, 1000, 0, null],
        ["rdiff", [37, 39], "practice trial 2", 1, null, 1, 39],
        ["fix", -1, "fixation", 0, 1000, 0, null],
        ["lsame", [37, 39], "practice trial 4", 1, null, 1, 37],
        ["fix", -1, "fixation", 0, 1000, 0, null],
        ["rsame", [37, 39], "practice trial 4", 1, null, 1, 39],
        ["fix", -1, "fixation", 0, 1000, 0, null],
        ["ldiff", [37, 39], "practice trial 4", 1, null, 1, 37]
        ["thanks", null, "Thanks", 0, null, 0, null],
];

i = 0;
last_time = 0;
can_advance = false;
data_log = Array();
$(document).keyup(function(e) {
    key = e.which; //(e.keyCode ? e.keyCode : e.which);
    if (i >= data.length-1) //Last slide
        return;
    if (isin(key, data[i][ACCEPT_KEY]) || can_advance == true) {
        //alert(key + data[i][ACCEPT_KEY] + isin(key, data[i][ACCEPT_KEY]));
        time = 0;
        if (data[i][SAVE_LATENCY] == 1)
            time = stop_timer();
        if (data[i][SAVE_DATA] == 1)
            data_log.push([i, time, key, data[i][CORRECT] == key, data[i][CORRECT], data[i][NOTES], data[i][SLIDE_ID]]);
        i++;
        can_advance = false;
        if (i >= data.length-1) {
            send_log();
        }
        $(".page").hide();
        $("#page_"+data[i][SLIDE_ID]).show();
        $(document).trigger("slidechanged");
        if (data[i][TIME])
            setTimeout(next_slide, data[i][TIME]);
        if (data[i][SAVE_LATENCY] == 1)
            start_timer();
    }
});
            
function isin(v, a) {
    if (a == null) //Null means accept anything
        return true;
    if (typeof(a) != 'object') 
        return false; //Not an array
    j = 0;
    while (j < a.length) {
        if (v == a[j])
            return true;
        j++;
    }
    return false;
}

function start_timer() {
    last_time = new Date(); 
}

function stop_timer() {
    new_time = new Date();
    return (new_time.getTime()-last_time.getTime());
}

function send_log() {
    data_joined = "i, latency, key pressed, was correct, correct answer, notes, slide\n";
    for(k=0; k<data_log.length; k++) {
        data_arr = data_log[k];
        data_joined = data_joined + data_arr.join(",") + "\n";
    }
    alert(data_joined);
    $.post(SUBMIT_URL, {data: data_joined, pname: $("#pname").value});
}

function next_slide() {
    can_advance = true;
    $(document).keyup();
}

$(document).ready(function(){
    $(".page").hide();
    $("#page_"+data[0][SLIDE_ID]).show();
    if (data[0][SAVE_LATENCY] == 1)
        start_timer();
});

/*******************************************************************
Each slide is tested for a callback function to update 
things on the slide when it is loaded.  It is accessed 
in the form:
        load_slide_SLIDEID
where SLIDEID is obviously the slide's id (the html id minus
the "page_" prefix).  The arguments are as follows:
        1. Array of all the slides that will be displayed, ordered
           as documented at the beginning of this file.
        2. Current index of the aforementioned array 
        3. List of data results, ordered as documented at the 
           beginning of this file.
********************************************************************/


//Stuff to change slides and whatnot
$(document).bind("slidechanged", function() {
    cb = window["load_slide_"+data[i][SLIDE_ID]];
    if (typeof cb == 'function') {
        cb(i, data, data_log);
   } 
});

<?php
$filename = "data.csv";
//$filename = preg_replace("/[^a-zA-Z0-9\s]/", "", $_REQUEST['pname']) . ".csv";
$fhandle = fopen($filename, 'a');
fwrite($fhandle, $_REQUEST['data']);
fclose($fhandle);
?>
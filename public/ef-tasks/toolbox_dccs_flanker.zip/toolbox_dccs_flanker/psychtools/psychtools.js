/*******************************************************************
psychtools.js
Version 0.01
Copyright 2011 Max Shinn

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Terminology:
    - SLIDE : A div in the html file describing a layout
    - PAGE : A particular showing of a slide (described by a big 
      array)
    - TRIAL : A grouping of pages, described by an array of pages

To use psychtools:
    - Call add_slides with data indexed according to the array below
    - Make your slides in HTML with a <div class="page" id="slide_X">
      where X is the slide ID, and a <div class="content"> within 
      the slide div.
    - You can also use <div class="instructions"> for instructions
      within a slide
    - Custom javascript for slides is documented below.
    - Define a data_sent function for a callback on data being sent
    - Define the function process_keypress_data to change the key
      code responses to something more readable for the data file. 
      It takes a keycode as an argument and outputs a string.
********************************************************************/
SUBMIT_URL = "log.php";

//Page order format
PAGE_SLIDE = 0;
PAGE_ACCEPT_KEY = 1;
PAGE_NOTES =  2;
PAGE_SAVE_LATENCY = 3;
PAGE_TIME = 4;
PAGE_SAVE_DATA = 5;
PAGE_CORRECT = 6;

//Data results format
RESULTS_PARTICIPANT = 0;
RESULTS_INDEX = 1;
RESULTS_LATENCY = 2;
RESULTS_KEY_PRESSED = 3;
RESULTS_CORRECT = 4;
RESULTS_ACTUAL = 5;
RESULTS_NOTES = 6;
RESULTS_PAGE = 7;




_pages = Array();
_id = null;
i = 0;
last_time = 0;
can_advance = false;
data_log = Array();
data_log_tmp = Array();
_timeoutinfo = null;
_cancel_call = false;
_next_page_override = null;

cb = window["process_keypress_data"];
if (typeof cb != 'function') {
    function process_keypress_data(keycode) {
        return keycode;
    }
} 


function advance_slide(e) {
    key = e.which; //(e.keyCode ? e.keyCode : e.which);
    $(document).trigger("slidesaved");
    if (_cancel_call == true) {
        _cancel_call = false;
        return;
    }
    if (i >= _pages.length-1) //Last slide
        return;
    if (isin(key, _pages[i][PAGE_ACCEPT_KEY]) || can_advance == true) {
        if (_timeoutinfo != null) {
            clearTimeout(_timeoutinfo);
            _timeoutinfo = null;
        }
        time = 0;
        if (_pages[i][PAGE_SAVE_LATENCY] == 1)
            time = stop_timer();
        if (_pages[i][PAGE_SAVE_DATA] == 1) {
            data_log.push([_id, i, time, process_keypress_data(key), _pages[i][PAGE_CORRECT] == key, _pages[i][PAGE_CORRECT], _pages[i][PAGE_NOTES], _pages[i][PAGE_SLIDE]]);
            data_log_tmp.push([_id, i, time, process_keypress_data(key), _pages[i][PAGE_CORRECT] == key, _pages[i][PAGE_CORRECT], _pages[i][PAGE_NOTES], _pages[i][PAGE_SLIDE]]);
        }
        if (_next_page_override != null) {
            i = _next_page_override;
            _next_page_override = null;
        }
        else
            i++;
        can_advance = false;
        if (i >= _pages.length-1) {
            send_log();
        }
        $(".slide").hide();
        $("#slide_"+_pages[i][PAGE_SLIDE]).show();
        $(document).trigger("slideloaded");
        if (_pages[i][PAGE_TIME])
            _timeoutinfo = setTimeout(next_slide, _pages[i][PAGE_TIME]);
        if (_pages[i][PAGE_SAVE_LATENCY] == 1)
            start_timer();
    }
}

function add_pages(slide_list) {
    _pages = _pages.concat(slide_list);
}

function advance_to(page_id) {
    can_advance = true;
    i = page_id;
    $(document).keydown();
}    

function override_next_page(page_id) {
    _next_page_override = page_id;
}

/*******************************************************************
Adds trials to the experiment.  The array of trials should be in
trial_list.  Then, trial_order is a string of the indexes of the array
trials. So for example...  
add_trials("0201120211210", Array(trial1,trial2, trial3)) 
********************************************************************/
function add_trials_list(trial_order, trial_list) {
    for (j=0; j<trial_order.length; j++) {
        index = parseInt(trial_order.substr(j, 1));
        add_pages(trial_list[index]);
    }
}

function add_trials(trial_list) {
    for (j=0; j<trial_list.length; j++) {
        add_pages(trial_list[j]);
    }
}

function set_id(id) {
    _id = id.replace(/(\r\n|\n|\r)/gm,"");
}

function isin(v, a) {
    if (a == null) //Null means accept anything
        return true;
    if (typeof(a) != 'object') 
        return false; //Not an array
    j = 0;
    while (j < a.length) {
        if (v == a[j])
            return true;
        j++;
    }
    return false;
}

function start_timer() {
    last_time = new Date(); 
}

function stop_timer() {
    new_time = new Date();
    return (new_time.getTime()-last_time.getTime());
}

function send_log() {
    data_joined = "";
    for(k=0; k<data_log_tmp.length; k++) {
        data_arr = data_log_tmp[k];
        data_joined = data_joined + data_arr.join(",") + "\n";
    }
    data_log_tmp = Array();
    $.post(SUBMIT_URL, {data: data_joined});
    //Callback function
    if (typeof data_sent == 'function') {
        data_sent(data_log);
    } 
}

function next_slide() {
    can_advance = true;
    $(document).keydown();
}

$(document).ready(function(){
    $(".slide").hide();    
    while (!_id)
        set_id(prompt("Please enter your ID number:"));
    $("#slide_"+_pages[0][PAGE_SLIDE]).show();
    if (_pages[0][PAGE_SAVE_LATENCY] == 1)
        start_timer();
    if (_pages[0][PAGE_TIME])
        setTimeout(next_slide, _pages[1][PAGE_TIME]);

    //Set the keydown function to move the slide
    $(document).keydown(advance_slide);
});

/*******************************************************************
Each slide is tested for a callback function to update 
things on the slide when it is loaded.  It is accessed 
in the form:
        load_slide_SLIDEID
              or
        save_slide_SLIDEID
where SLIDEID is obviously the slide's id (the html id minus
the "slide_" prefix).  The arguments are as follows:
        1. Array of all the slides that will be displayed, ordered
           as documented at the beginning of this file.
        2. Current index of the aforementioned array 
        3. List of data results, ordered as documented at the 
           beginning of this file.
The functions load_slide and save_slide (without _SLIDEID) 
are called after every slide load or save.
********************************************************************/

//Stuff to change slides and whatnot
$(document).bind("slidesaved", function() {
    cb = window["save_slide_"+_pages[i][PAGE_SLIDE]];
    if (typeof cb == 'function') {
        cb(i, _pages, data_log);
   } 
    cb = window["save_slide"];
    if (typeof cb == 'function') {
        cb(i, _pages, data_log);
   } 
});
//Stuff to change slides and whatnot
$(document).bind("slideloaded", function() {
    cb = window["load_slide_"+_pages[i][PAGE_SLIDE]];
    if (typeof cb == 'function') {
        cb(i, _pages, data_log);
   } 
    cb = window["load_slide"];
    if (typeof cb == 'function') {
        cb(i, _pages, data_log);
   } 
});

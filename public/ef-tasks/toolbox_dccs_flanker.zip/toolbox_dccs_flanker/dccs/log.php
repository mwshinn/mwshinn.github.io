<?php
$filename = "data.csv";

if ($_REQUEST['check']) {
    $id = PREG_REPLACE("/[^0-9a-zA-Z]/i", '', $_REQUEST['id']);
    $fhandle = fopen($filename, 'r');
    $text = fread($fhandle, filesize($filename));
    if (strpos($text, $id) === False)
        print "0";
    else
        print "1";
    exit();
}
else {
    $fhandle = fopen($filename, 'a');
    fwrite($fhandle, $_REQUEST['data']);
    fclose($fhandle);
}
?>
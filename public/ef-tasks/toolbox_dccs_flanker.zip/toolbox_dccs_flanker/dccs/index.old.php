<html>
<head>
<script type="text/javascript" src="../psychtools/jquery-1.6.2.min.js"></script>
<script type="text/javascript" src="../psychtools/psychtools.js"></script>
<script type="text/javascript">
SAVE_CONTINUOUSLY = true;

intro = [
        ["intro", [32], "Intro", 0, null, 0, null],
        ["inst1", [39], "Instructions 1", 0, null, 0, null],
        ["inst2", [37], "Instructions 2", 0, null, 0, null],
        ["inst3", [32], "Are you ready?", 0, null, 0, null],
        /*Practice 1*/
        ["pfixation", -1, "fixation", 0, 1000, 0, null],
        ["pshape", -1, "sort by shape", 0, 1000, 0, null],
        ["whiteboat", [37, 39], "practice", 1, 10000, 1, 39],
        ["feedback", [32], "Feedback page", 0, null, 0, null],
        ["pfixation", -1, "fixation", 0, 1000, 0, null],
        ["pshape", -1, "sort by shape", 0, 1000, 0, null],
        ["greenrabbit", [37, 39], "practice", 1, 10000, 1, 37],
        ["feedback", [32], "Feedback page", 0, null, 0, null],
        ["pfixation", -1, "fixation", 0, 1000, 0, null],
        ["pshape", -1, "sort by shape", 0, 1000, 0, null],
        ["greenrabbit", [37, 39], "practice", 1, 10000, 1, 37],
        ["feedback", [32], "Feedback page", 0, null, 0, null],
        ["pfixation", -1, "fixation", 0, 1000, 0, null],
        ["pshape", -1, "sort by shape", 0, 1000, 0, null],
        ["whiteboat", [37, 39], "practice", 1, 10000, 1, 39],
        ["feedback", [32], "Feedback page", 0, null, 0, null],
        /*More instructions*/
        ["inst4", [39], "Instructions 4", 0, null, 0, null],
        ["inst5", [37], "Instructions 5", 0, null, 0, null],
        ["inst3", [32], "Are you ready?", 0, null, 0, null],
        /*Practice 2*/
        ["pfixation", -1, "fixation", 0, 1000, 0, null],
        ["pcolor", -1, "sort by color", 0, 1000, 0, null],
        ["whiteboat", [37, 39], "practice", 1, 10000, 1, 37],
        ["feedback", [32], "Feedback page", 0, null, 0, null],
        ["pfixation", -1, "fixation", 0, 1000, 0, null],
        ["pcolor", -1, "sort by color", 0, 1000, 0, null],
        ["greenrabbit", [37, 39], "practice", 1, 10000, 1, 39],
        ["feedback", [32], "Feedback page", 0, null, 0, null],
        ["pfixation", -1, "fixation", 0, 1000, 0, null],
        ["pcolor", -1, "sort by color", 0, 1000, 0, null],
        ["whiteboat", [37, 39], "practice", 1, 10000, 1, 37],
        ["feedback", [32], "Feedback page", 0, null, 0, null],
        ["pfixation", -1, "fixation", 0, 1000, 0, null],
        ["pcolor", -1, "sort by color", 0, 1000, 0, null],
        ["greenrabbit", [37, 39], "practice", 1, 10000, 1, 39],
        ["feedback", [32], "Feedback page", 0, null, 0, null],
        /*Time to go for real*/
        ["inst9", [32], "Instructions 9", 0, null, 0, null],
];
_START_PRACTICE_2 = 20;

pre_instr = [
        ["preinstr1", [32], "Preswitch Instructions 1", 0, null, 0, null],
        ["preinstr2", [39], "Preswitch Instructions 2", 0, null, 0, null],
        ["preinstr3", [37], "Preswitch Instructions 3", 0, null, 0, null],
];

post_instr = [
        ["postinstr1", [32], "Postswitch Instructions 1", 0, null, 0, null],
        ["postinstr2", [39], "Postswitch Instructions 2", 0, null, 0, null],
        ["postinstr3", [37], "Postswitch Instructions 3", 0, null, 0, null],
];        
mixed_instr = [
        ["inst6", [32], "Instructions 6", 0, null, 0, null],
        ["inst7", [32], "Instructions 7", 0, null, 0, null],
        ["inst8", [32], "Instructions 8", 0, null, 0, null],
];
thanks = [
        ["thanks", -1, "first slide", 0, null, 0, null]
];


pre_y = [
        ["isi", -1, "isi", 0, 800, 0, null],
        ["fixation", -1, "fixation", 0, 1000, 0, null],
        ["shape", -1, "sort by shape", 0, 1000, 0, null],
        ["yellowball", [37, 39], "preswitch", 1, 10000, 1, 37]
];
pre_b = [
        ["isi", -1, "isi", 0, 800, 0, null],
        ["fixation", -1, "fixation", 0, 1000, 0, null],
        ["shape", -1, "sort by shape", 0, 1000, 0, null],
        ["bluetruck", [37, 39], "preswitch", 1, 10000, 1, 39]
];
post_t = [
        ["isi", -1, "isi", 0, 800, 0, null],
        ["fixation", -1, "fixation", 0, 1000, 0, null],
        ["color", -1, "sort by color", 0, 1000, 0, null],
        ["bluetruck", [37, 39], "postswitch", 1, 10000, 1, 37],
];
post_b = [
        ["isi", -1, "isi", 0, 800, 0, null],
        ["fixation", -1, "fixation", 0, 1000, 0, null],
        ["color", -1, "sort by color", 0, 1000, 0, null],
        ["yellowball", [37, 39], "postswitch", 1, 10000, 1, 39],
];
cbt = [
        ["isi", -1, "isi", 0, 800, 0, null],
        ["fixation", -1, "fixation", 0, 1000, 0, null],
        ["color", -1, "sort by color", 0, 1000, 0, null],
        ["bluetruck", [37, 39], "nondominant", 1, 10000, 1, 37]
];
cyb = [
        ["isi", -1, "isi", 0, 800, 0, null],
        ["fixation", -1, "fixation", 0, 1000, 0, null],
        ["color", -1, "sort by color", 0, 1000, 0, null],
        ["yellowball", [37, 39], "nondominant", 1, 10000, 1, 39]
];
sbt = [
        ["isi", -1, "isi", 0, 800, 0, null],
        ["fixation", -1, "fixation", 0, 1000, 0, null],
        ["shape", -1, "sort by shape", 0, 1000, 0, null],
        ["bluetruck", [37, 39], "dominant", 1, 10000, 1, 39],
];
syb = [
        ["isi", -1, "isi", 0, 800, 0, null],
        ["fixation", -1, "fixation", 0, 1000, 0, null],
        ["shape", -1, "sort by shape", 0, 1000, 0, null],
        ["yellowball", [37, 39], "dominant", 1, 10000, 1, 37],
];

preswitch = [
pre_y,
pre_b,
pre_y,
pre_b,
pre_b
];

postswitch = [
post_t,
post_b,
post_b,
post_t,
post_t
];

trials = [
sbt,
syb,
syb,
sbt,
cbt,
syb,
sbt,
sbt,
cyb,
sbt,
sbt,
syb,
sbt,
syb,
cyb,
sbt,
syb,
cbt,
syb,
syb,
sbt,
cbt,
syb,
sbt,
syb,
sbt,
cyb,
syb,
sbt,
cyb
];
//Ugly hack to randomize fixation time
for (l in trials.length) {
    trials[l][1][4] = t[l][1][4] + Math.floor(Math.random()*501);
}

add_pages(intro);
add_pages(pre_instr);
add_trials(preswitch);
add_pages(post_instr);
add_trials(postswitch);
add_pages(mixed_instr);
add_trials(trials);

add_pages(thanks);

correct_answers = 0;
incorrect_answers = 0;
incorrect_sets = 0;
practice_round = 1;

function load_slide_feedback(i, data, data_log) {
    if (data_log.length == 0)
        return;
    $('.correct, .incorrect').hide();
    if (data_log[data_log.length-1][RESULTS_CORRECT] == true) {
        $('.correct').show();
        correct_answers++;
    }
    else {
        $('.incorrect').show();
        if(data_log[data_log.length-1][RESULTS_ACTUAL] == 37) 
            $('.whiterabbit').addClass('highlighted');
        else
            $('.greenboat').addClass('highlighted');
        incorrect_answers++;
    }
}
    

function save_slide_feedback(i, data, data_log) {
    //Repeat if they got 2+ wrong
    $('.cardcontainercell').removeClass('highlighted');
    if (correct_answers + incorrect_answers >= 4) {
        if (incorrect_answers >= 2) {
            //Repeat on two or fewer sets wrong, and quit otherwise
            if (incorrect_sets > 2) 
                override_next_page(data.length-1);
            else {
                if (practice_round == 1)
                    override_next_page(0);
                else
                    override_next_page(_START_PRACTICE_2);
            }
            correct_answers = 0;
            incorrect_answers = 0;
            incorrect_sets += 1;
        }
        else {
            //Reset for the next practice round
            correct_answers = 0;
            incorrect_answers = 0;
            incorrect_sets = 0;
            practice_round +=1;
        }
    }
}

function save_slide(i, data, data_log) {
    if (data_log.length == 0)
        return;
    if (data[i][PAGE_NOTES] != "preswitch" && data[i][PAGE_NOTES] != "postswitch") 
        return;

    if (data_log[data_log.length-1][RESULTS_CORRECT] == true && data_log[data_log.length-1][RESULTS_NOTES].indexOf("switch") != -1) {
        correct_answers++;
    }
    else if (data_log[data_log.length-1][RESULTS_NOTES].indexOf("switch") != -1) {
        incorrect_answers++;
    }

    if ((practice_round == 2 || practice_round == 3) && correct_answers + incorrect_answers >= 5) {
        if (incorrect_answers >= 2) {
            //Repeat on two or fewer sets wrong, and quit otherwise
            override_next_page(data.length-1);
        }
        else {
            //Reset for the next practice round
            correct_answers = 0;
            incorrect_answers = 0;
            incorrect_sets = 0;
            practice_round += 1;
        }
    }
}    

function load_slide_OLDDUMMY(i, data, data_log) {
    if (data_log.length == 0)
        return;
    if (data_log[data_log.length-1][RESULTS_NOTES] != "preswitch" && data_log[data_log.length-1][RESULTS_NOTES] != "postswitch") 
        return;

    if (data_log[data_log.length-1][RESULTS_CORRECT] == true) {
        correct_answers++;
    }
    else {
        alert("adding incorrect");
        incorrect_answers++;
    }
}

//This requires HTML5!!!
shape_aud = Audio("stimuli/shape.wav");
color_aud = Audio("stimuli/color.wav");

function load_slide_shape(i, data, data_log) {
    shape_aud.play();
}

function load_slide_color(i, data, data_log) {
    color_aud.play();
}

function load_slide_pshape(i, data, data_log) {
    shape_aud.play();
}

function load_slide_pcolor(i, data, data_log) {
    color_aud.play();
}


//Change stuff if we are saving as we go
if (SAVE_CONTINUOUSLY) {
    //Send the log periodically
    function load_slide_isi() {
        send_log();
    }
}
else {
    function data_sent(data) {
        $('.sending-data').hide();
        $('.data-sent').show();
    }
}
</script>
<link rel="stylesheet" type="text/css" href="../psychtools/psychtools.css" />
<link rel="stylesheet" type="text/css" href="dccs.css" />
<?php
function draw_boxes_practice() { 
?>
<table class="cardcontainers"><tr height="300px;"><td class="cardcontainersidecell"> </td><td class="cardcontainercell whiterabbit"><img src="stimuli/whiterabbit.jpg"></td><td class="cardcontainercentercell"> </td><td class="cardcontainercell greenboat"><img src="stimuli/greenboat.jpg"></td><td class="cardcontainersidecell"> </td></tr></table>
<?php 
} 
function draw_boxes() { 
?>
<table class="cardcontainers"><tr height="300px;"><td class="cardcontainersidecell"> </td><td class="cardcontainercell"><img src="stimuli/blueball.jpg"></td><td class="cardcontainercentercell"> </td><td class="cardcontainercell"><img src="stimuli/yellowtruck.jpg"></td><td class="cardcontainersidecell"> </td></tr></table>
<?php 
} 
?>
</head>
<body>

<div class="slide" id="slide_intro">
<div class="content">
<div class="instructions">
The teacher needs your help putting away all of these toys!  Press the space bar to continue.</div>
<img src="stimuli/teacher.jpg">
</div>
</div>

<div class="slide" id="slide_inst1">
<div class="content">
<div class="instructions">
You're going to play a matching game.<br />If you see the word SHAPE, select the picture that is the same SHAPE as the picture in the middle of the screen using the arrow keys.<br />If it's a Boat, press the right arrow on your keyboard.
</div>
<img src="stimuli/whiteboat.jpg">
<div class="instructions">Press the right arrow to continue</div>
<?php draw_boxes_practice(); ?>
</div>
</div>

<div class="slide" id="slide_inst2">
<div class="content">
<div class="instructions">
If it's a Rabbit, press the left arrow on your keyboard.
</div>
<img src="stimuli/greenrabbit.jpg">
<div class="instructions">Press the left arrow to continue</div>
<?php draw_boxes_practice(); ?></div>
</div>

<div class="slide" id="slide_inst3">
<div class="content">
<div class="instructions">
Now you'll have a chance to practice.<br />
Keep your eyes on the <img src="stimuli/star.jpg"> you will see in the middle of the screen.<br />
Try to answer as fast as you can without making mistakes.  If you make a mistake, just keep going.<br />
Press the space bar when you're ready to continue.
</div>
</div>
</div>

<div class="slide" id="slide_inst4">
<div class="content">
<div class="instructions">
You can also match by color.<br />If you see the word COLOR, select the picture that is the same COLOR as the picture in the middle of the screen using the arrow keys.<br />If it's a Green one, press the right arrow on your keyboard.
</div>
<img src="stimuli/greenrabbit.jpg">
<div class="instructions">Press the right arrow to continue</div>
<?php draw_boxes_practice(); ?>
</div>
</div>

<div class="slide" id="slide_inst5">
<div class="content">
<div class="instructions">
If it's a White one, press the left arrow on your keyboard.
</div>
<img src="stimuli/whiteboat.jpg">
<div class="instructions">Press the left arrow to continue</div>
<?php draw_boxes_practice(); ?></div>
</div>

<div class="slide" id="slide_inst6">
<div class="content">
<div class="instructions">
Now we're going to play BOTH games together, so pay attention!!
<br />
<br />
Press the space bar to continue.
</div>
</div>
</div>

<div class="slide" id="slide_inst7">
<div class="content">
<div class="instructions">
If you see the word SHAPE, select the picture that is the same SHAPE as the picture in the middle of the screen.<br />
<br />
Press the space bar to continue.
</div>
<?php draw_boxes(); ?>
</div>
</div>

<div class="slide" id="slide_inst8">
<div class="content">
<div class="instructions">
If you see the word COLOR, select the picture that is the same COLOR as the picture in the middle of the screen.<br />
<br />
Press the space bar to continue.
</div>
</div>
</div>

<div class="slide" id="slide_inst9">
<div class="content">
<div class="instructions">
Press the space bar to start!
</div>
</div>
</div>

<div class="slide" id="slide_preinstr1">
<div class="content">
<div class="instructions">
Remember, if you see the word SHAPE, select the picture that is the same SHAPE as the picture in the middle of the screen.<br />
<br />
Press the space bar to continue.
</div>
</div>
</div>

<div class="slide" id="slide_preinstr2">
<div class="content">
<div class="instructions">
If it's a Truck, press the right arrow on your keyboard.
</div>
<img src="stimuli/bluetruck.jpg">
<div class="instructions">Press the right arrow to continue</div>
<?php draw_boxes(); ?>
</div>
</div>

<div class="slide" id="slide_preinstr3">
<div class="content">
<div class="instructions">
If it's a Ball, press the left arrow on your keyboard.
</div>
<img src="stimuli/yellowball.jpg">
<div class="instructions">Press the left arrow to continue</div>
<?php draw_boxes(); ?></div>
</div>

<div class="slide" id="slide_postinstr1">
<div class="content">
<div class="instructions">
Remember, if you see the word COLOR, select the picture that is the same COLOR as the picture in the middle of the screen.<br />
<br />
Press the space bar to continue.
</div>
</div>
</div>

<div class="slide" id="slide_postinstr2">
<div class="content">
<div class="instructions">
If it's a Yellow one, press the right arrow on your keyboard.
</div>
<img src="stimuli/yellowball.jpg">
<div class="instructions">Press the right arrow to continue</div>
<?php draw_boxes(); ?>
</div>
</div>

<div class="slide" id="slide_postinstr3">
<div class="content">
<div class="instructions">
If it's a Blue one, press the left arrow on your keyboard.
</div>
<img src="stimuli/bluetruck.jpg">
<div class="instructions">Press the left arrow to continue</div>
<?php draw_boxes(); ?></div>
</div>

<div class="slide" id="slide_isi">
<div class="content">
<div class="instructions">
</div>
<?php draw_boxes(); ?>
</div>
</div>

<div class="slide" id="slide_fixation">
<div class="content">
<div class="instructions">
<br /><br />
<img src="stimuli/star.jpg">
</div>
<?php draw_boxes(); ?>
</div>
</div>

<div class="slide" id="slide_shape">
<div class="content">
<div class="instructions">
<br /><br />
SHAPE
</div>
<?php draw_boxes(); ?>
</div>
</div>

<div class="slide" id="slide_color">
<div class="content">
<div class="instructions">
<br /><br />
COLOR
</div>
<?php draw_boxes(); ?>
</div>
</div>

<div class="slide" id="slide_pfixation">
<div class="content">
<div class="instructions">
<br /><br />
<img src="stimuli/star.jpg">
</div>
<?php draw_boxes_practice(); ?>
</div>
</div>

<div class="slide" id="slide_pshape">
<div class="content">
<div class="instructions">
<br /><br />
SHAPE
</div>
<?php draw_boxes_practice(); ?>
</div>
</div>

<div class="slide" id="slide_pcolor">
<div class="content">
<div class="instructions">
<br /><br />
COLOR
</div>
<?php draw_boxes_practice(); ?>
</div>
</div>

<div class="slide" id="slide_greenrabbit">
<div class="content">
<div class="instructions">
<img src="stimuli/greenrabbit.jpg">
</div>
<?php draw_boxes_practice(); ?>
</div>
</div>

<div class="slide" id="slide_whiteboat">
<div class="content">
<div class="instructions">
<img src="stimuli/whiteboat.jpg">
</div>
<?php draw_boxes_practice(); ?>
</div>
</div>

<div class="slide" id="slide_yellowball">
<div class="content">
<div class="instructions">
<img src="stimuli/yellowball.jpg">
</div>
<?php draw_boxes(); ?>
</div>
</div>

<div class="slide" id="slide_bluetruck">
<div class="content">
<div class="instructions">
<img src="stimuli/bluetruck.jpg">
</div>
<?php draw_boxes(); ?>
</div>
</div>

<div class="slide" id="slide_feedback">
<div class="content">
<div class="instructions">
<div style="display: none" class="correct">
Good job!  That was right!
</div>
<div style="display: none" class="incorrect">
Oops!  That was wrong!  You should have selected:
</div>
Press the space bar to continue.
</div>
<?php draw_boxes_practice(); ?>
</div>
</div>

<div class="slide" id="slide_thanks">
<div class="content">
<div class="instructions">
Thank you!  You have completed the task.  You may now close out of this browser window.
</div>
</div>
</div>

</body>
</html>

/*****************  THINGS TO CHANGE in v2
- Objects should be used instead of arrays
    - Constructor contains only slide ID and notes
    - Has the following assignable with the following default values:
        - time = 0 (the time until continuing to the next slide automatically)
        - record_latency = false (record the time spent on this page and save it)
        - next = ?? (thinking of this as a linked list, the next node)
        - prev = ?? (again, the previous node)
        - label = "" (a label for a goto function)
        - accept_on_keys = Array() (an array that, when this is the response, moves onto the next page. {RETURN} or something is used for return, arrows, etc. So [key("{RETURN}"), key("a"), key("b")] would accept those keys.  The key function is case insensitive..
        - correct_answer = none (what is the correct answer?)
        - save_data = false (should the data from this slide be saved to the log file?) (maybe this needs to be set in the constructor?)
    - The following functions can be defined:
        - load() (called right before the slide loads)
        - save() (called right before the slide closes and the next slide is loaded)
            - If save() returns false, the next slide is not loaded.
    - Has the following normal functions:
        - latency() (returns the total time the page was displayed.  If it is still being displayed, this will be increasing.  If not, it will be static.)
        - correct() (returns true if the response was correct.  Useful with the ".prev" variable or in save()
        - respond(response) (decrees that "response" takes the place of an acceptable keypress, and saves this as the response, continuing on to the next page.)
- Data results shouldn't be stored, but rather generated and parsed later.  **NOTE!!  Duplicating a javascript object is difficult... normal assignment just creates a reference.  Figure this out before starting anything.***
- The participant's id can be passed via a url

                                           ***********************/

//Standard keys
_KEYCODES = new Array();
_KEYCODES["{RETURN}"] = 13;
_KEYCODES["{LEFT}"] = 37;
_KEYCODES["{RIGHT}"] = 39;
_KEYCODES["{UP}"] = 38;
_KEYCODES["{DOWN}"] = 40;
_KEYCODES["{SHIFT}"] = 16;
_KEYCODES["{BACKSPACE}"] = 8;
_KEYCODES["{ESCAPE}"] = 27;
_KEYCODES["{CTRL}"] = 17;
_KEYCODES["{SPACE}"] = 32;

//Flip this array around into _KEYS for Omega 1 searching
_KEYS = new Array();
for (var k in _KEYCODES) {
    _KEYS[_KEYCODES[k]] = k;
}

//Returns the keycode (event.which) associated with the string passed.
//The indexes of the _KEYCODES array can be used.  Do NOT pass strange
//keys to this, including (but not limited to) =, -, and ;.  These
//don't work the same way on all browsers.  Returns nothing if the
//string passed is invalid.
function KEY(keystr) {
    keystr = keystr.toString();
    if (!keystr || (keystr.length > 1 && keystr.charAt(0) != "{")) return "";
    keystr = keystr.toUpperCase();
    if (keystr in _KEYCODES)
        return _KEYCODES[keystr];
    else
        //NOTE: This function is weird.  It returns ascii values, and
        //hence treats capitals differently than lowercase.  (Capitals
        //seem to be the same as keycodes for alphanumerics, though.) 
        //Use something else if it becomes available.
        return keystr.charCodeAt(0);  
}

//Returns the key associated with a particular keycode.  This cannot
//be counted on as reliable in all cases, especially with odd keys.
//With alphanumerics, however, it works in all cases that KEY(keystr)
//works.
function KEYCODE(keycode) {
    if (!keycode || parseInt(keycode) == NaN) return "";
    if (keycode in _KEYS)
        return _KEYS[keycode];
    return String.fromCharCode(keycode)
}


//Methods for the Page class

//Check if the response given was correct or not.  Returns false if no response was given
_correct = function() {
    return ((this.response_key != null && this.response_key == this.correct_answer) || 
            (this.response != null && this.response == this.correct_answer));
}
//Measures how long the page has been displayed for, or the total time it was displayed (if currently hidden)
_latency = function() {
    if (this._start_time == null) return 0;
    if (this._end_time == null) {
        current_time = new Date();
        return (current_time.getTime() - this._start_time.getTime());
    }
    return (this._end_time.getTime() - this._start_time.getTime())
}

//Returns the next slide SEQUENTIALLY (ignoring next slide overrides)
_next = function() {
    current_id = psychtools.index_of(this);
    if (current_id >= psychtools._pages.length) {
        psychtools.report_error("Can't get next slide because we're already on the last slide!");
        return current_id;
    }
    return psychtools._pages[current_id+1];
}

//Returns the previous slide SEQUENTIALLY (ignoring next slide
//overrides)
_prev = function() {
    current_id = psychtools.index_of(this);
    if (current_id >= psychtools._pages.length) {
        psychtools.report_error("Can't get previous slide because we're already on the first slide!");
        return current_id;
    }
    return psychtools._pages[current_id-1];
}
    

_prepare = function() {
    this._start_time = new Date();
}

_terminate = function() {
    this._end_time = new Date();
}

_blank = function() { return true; }

//The Page class.  "slide_id" is the id of the html slide, save_data
//is true or false (whether or not to log the participant's response)
//and notes is a general description of the page.
function Page(slide_id, save_data, notes)
{
    //Check for typos
    if (typeof slide_id != 'string' || typeof save_data != 'boolean' || typeof notes != 'string')
        psychtools.report_error("Error in Page declaration")
    //Values from arguments
    this.slide_id = slide_id;
    this.notes = notes;
    this.save_data = save_data;
    //Default values that can be set by the user
    this.correct_answer = null;
    this.record_latency = false;
    this.time = 0;
    this.accept_on_keys = ""
    this.label = "";
    this.response = null; //Set to the response string
    this.response_key = null; //Set to the keypress
    //Internally-used values (should not be modified by user)
    this._start_time = null;
    this._end_time = null;
    //Methods that the user can use
    this.correct = _correct;
    this.latency = _latency;
    this.next = _next;
    this.prev = _prev;
    //Methods currently undefined that the user can set
    this.load = _blank;
    this.save = _blank;
    //Internally-used methods (should not be called by the user)
    this._prepare = _prepare;
    this._terminate = _terminate;
}

/*******************************************************************
psychtools.js
Version 0.02
Copyright 2011-2012 Max Shinn

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Terminology:
    - SLIDE : A div in the html file describing a layout
    - PAGE : A particular showing of a slide (described by a big 
      array)
    - TRIAL : A grouping of pages, described by an array of pages

To use psychtools:
    - Call add_slides with data indexed according to the array below
    - Make your slides in HTML with a <div class="page" id="slide_X">
      where X is the slide ID, and a <div class="content"> within 
      the slide div.
    - You can also use <div class="instructions"> for instructions
      within a slide
    - Custom javascript for slides is documented below.
    - Define a data_sent function for a callback on data being sent
    - Define the function process_keypress_data to change the key
      code responses to something more readable for the data file. 
      It takes a keycode as an argument and outputs a string.
********************************************************************/
SUBMIT_URL = "log.php";

//We need to emulate a namespace here with an object.
var psychtools = {}

//Sets the psychtools variables.  This must be called when the page loads
psychtools.initialize = function() {
    //Define some general variables
    psychtools._pages = Array(); //An array of all of the pages.  Each must be a unique instance of the object Page().
    this._id = null; //Participant's id
    this._i = 0; //The current page we are on.  It's used frequently, and this is extremely short. :)
    this._data_log = Array();
    this._timeoutinfo = null; //Remembers if a slide needs to be changed after a certain amount of time
    this._next_page_override = null;
    this._save_continuously = false; //Save as the log is updated
    this._saving = false; //Are we in the process of communicating with the server?
}

psychtools.begin = function() {
    //Prepare stuff
    $(".slide").hide();

    //Set the participant's ID via the URL, or prompt if it is not given
    if (this._id == null)
        this._id = (location.search.match(RegExp('[?|&]id=(.+?)(&|$)')) || [null,null])[1];
    while (!this._id) {
        this._id = prompt("Please enter your ID number:");
        this._id = this._id.replace(/(\r\n|\n|\r)/gm,"");
    }

    //Display the first page
    $("#slide_"+this._pages[0].slide_id).show();
    if (this._pages[0].time != 0)
        this._timeoutinfo = setTimeout("psychtools.advance_slide()", this._pages[0].time);
    this._pages[0]._prepare();

    //Set the keydown callback
    $(document).keydown(psychtools.keypress_callback);
}

psychtools.assign_random_id = function() {
    this._id = Math.floor(Math.random() * 1000000).toString();
}

//Responds to keypresses, and triggers 
psychtools.keypress_callback = function(e) {
    if ($.inArray(e.which, psychtools._pages[psychtools._i].accept_on_keys) == -1) return;
    psychtools._pages[psychtools._i].response_key = e.which;
    psychtools.advance_slide();
}
psychtools.advance_slide = function() {
    //Make sure we should go to the next slide in the first place.
    if (this._pages[this._i].save() == false) return;
    if (this._i >= this._pages.length-1) //Last slide
        return;

    //This manages moving onto the next page automatically after a certain amount of time
    if (this._timeoutinfo != null) {
        clearTimeout(this._timeoutinfo);
        this._timeoutinfo = null;
    }

    //Stop the timer
    this._pages[this._i]._terminate(); 

    //Save things to the log
    if (this._pages[this._i].save_data == true) {
        this.save_to_log();
        if (this._save_continuously)
            this.send_log();
    }
    
    //Go to the next page, or to a different one?
    if (this._next_page_override != null) {
        this._i = this._next_page_override;
        this._next_page_override = null;
    }
    else
        this._i++;

    //Now we begin operating on the next slide, since i has changed.

    //Send the log if this is the last slide in the experiment
    if (this._i >= this._pages.length - 1) {
        this.send_log();
    }
    //Display the next slide
    $(".slide").hide();
    $("#slide_"+this._pages[this._i].slide_id).show();
    this._pages[this._i].load();
    if (this._pages[this._i].time != 0)
        this._timeoutinfo = setTimeout("psychtools.advance_slide()", this._pages[this._i].time);
    this._pages[this._i]._prepare();
}

//Saves the data from the current page to the log
psychtools.save_to_log = function() {
    line = Object();
    line["id"] = this._id;
    line["i"] = this._i; 
    line["slide_id"] = this._pages[this._i].slide_id;
    line["notes"] = this._pages[this._i].notes.replace(/,/g, "");
    line["correct_answer"] = (this._pages[this._i.correct_answer] == null ? "" : KEYCODE(this._pages[this._i].correct_answer));
    line["start_time"] = this._pages[this._i]._start_time.valueOf();
    line["end_time"] = this._pages[this._i]._end_time.valueOf();
    line["correct"] = this._pages[this._i].correct();
    line["latency"] = this._pages[this._i].latency();
    line["response"] = KEYCODE(this._pages[this._i].response_key) || this._pages[this._i].response;
    line["timestamp"] = Date().toString();
    this._data_log.push(line);
}

//Sends the log found in this._data_log to the server.  It will go
//either periodically or all at the end.
psychtools.send_log = function() {
    data_joined = "";
    for (i=0; i<this._data_log.length; i++) {
        data_array = Array();
        for (var prop in this._data_log[i]) {
            data_array.push(this._data_log[i][prop]);
        }
        data_joined = data_joined + data_array.join(",") + "\n";
    }
    this._data_log = Array();
    if (data_joined != "") {
        psychtools._saving = true;
        $.post(SUBMIT_URL, {data: data_joined}, psychtools.__sent_log_callback).error(function(){
            psychtools.report_error("Critical error: Server cannot be reached.")});
    }
    //Callback function
    if (typeof data_sent == 'function') {
        data_sent(this._data_log);
    } 
}

//Check to make sure the response was valid, and alert that saving is
//complete.
psychtools.__sent_log_callback = function(data, textStatus, jqXHR) {
    psychtools._saving = false;
    if (data.indexOf("error") != -1) {
        psychtools.report_error("Critical error: Server misconfiguration.  Data will not be saved.");
    }
}

//
psychtools.current_page = function() {
    return this._pages[this._i];
}
    

//Iterates through the list and addes them via add_page
psychtools.add_pages = function(slide_list) {
    for (var i in slide_list)
        this.add_page(slide_list[i]);
}

//Adds a new page.  It will create a copy of the object passed to it.
psychtools.add_page = function(page) {
    var copy = psychtools.duplicate_page(page);
    this._pages.push(copy)
}

psychtools.duplicate_page = function(page) {
    return $.extend(true, {}, page);
}

//Go directly to page with the label "label".  If multiple pages have
//this label, go to the first one.
psychtools.go_to = function(label) {
    this.override_next_page(this.label_to_i(label));
    this.advance_slide();
}

//Sets the next page to be the page with the label "label".  If
//multiple have it, go to the fisrt one.
psychtools.override_next_page = function(label) {
    this._next_page_override = this.label_to_i(label);
}

//Converts a label to the index.  Returns 0 on failure and reports an
//error.
psychtools.label_to_i = function(label) {
    for (var i=0; i<this._pages.length; i++) {
        if (this._pages[i].label == label)
            return i;
    }
    this.report_error("Specified label not found!  Defaulting to i=0.");
    return 0;
}

//Returns the index of a particular slide.  "slide" must be a
//reference to a particular instance of a Slide object.  This method
//assumes that the same instance of a slide does not appear in
//this._pages more than once.  Returns 0 on failure and reports an
//error.
psychtools.index_of = function(slide) {
    for (var i=0; i<this._pages.length; i++) {
        if (this._pages[i] === slide)
            return i;
    }
    this.report_error("Specified slide not found!  Defaulting to i=0.");
    return 0;
}

//This makes psychtools send the datalog periodically.  Don't use this
//if you have a slow connection!!
psychtools.enable_autosave = function() {
    this._save_continuously = true;
}

//Reports an error.  This can be changed to accomodate error
//suppression and different error reporting systems and whatnot.
psychtools.report_error = function(message) {
    alert(message);
}

//This function replaces the standard javascript redirect function.
//It functions exactly the same, except it checks to ensure that data
//is not being sent to the server during the redirect to prevent error
//messages.  If append_id is set to true, it will append the user's id
//to the GET data of the request.  This way, when redirecting to
//another psychtools task, the user will not be prompted for an id
//again.
psychtools.redirect = function(url, append_id) {
    if (this._saving == true) {window.setTimeout(function(){psychtools.redirect(url, append_id);}, 10); return;}
    suffix = '';
    if (append_id == true && url.search("\\?") == -1)
        suffix = '?id=' + this._id;
    else if (append_id == true)
        suffix = '&id=' + this._id;

    window.location.href = REDIRECT_URL + suffix;
}
        

/*******************************************************************
Adds trials to the experiment.  The array of trials should be in
trial_list, where each item in that array should be an array of pages.
Then, trial_order is a string of the indexes of the array trials. So
for example...
add_trials("0201120211210", Array(trial1,trial2, trial3)) 
********************************************************************/
psychtools.add_trials_list = function(trial_order, trial_list) {
    for (i=0; i<trial_order.length; i++) {
        index = parseInt(trial_order.substr(i, 1));
        this.add_pages(trial_list[index]);
    }
}

//The same as above, but adds them in sequential order.
psychtools.add_trials = function(trial_list) {
    for (i=0; i<trial_list.length; i++) {
        this.add_pages(trial_list[i]);
    }
}



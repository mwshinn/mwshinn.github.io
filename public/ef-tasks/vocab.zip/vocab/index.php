<html>
<head>
<script type="text/javascript" src="../psychtools2/jquery-1.6.2.min.js"></script>
<script type="text/javascript" src="../psychtools2/psychtools2.js"></script>
<script type="text/javascript">

REDIRECT_URL = '../dccs2/index.php';


intro = new Page("inst1", false, "Instructions");
intro.accept_on_keys = [KEY("{SPACE}")];
practice = new Page("practice", true, "Practice");
practice.correct_answer = "2";
feedback = new Page("feedback", false, "Feedback");
feedback.accept_on_keys = [KEY("{SPACE}")];
feedback.load = load_slide_feedback;
thanks = new Page("thanks", false, "thank you");
thanks.label = "last_slide";
thanks.load = load_slide_thanks;


<?php
$questions = Array(
                   Array("Loaf", "string", "coal", "wave", "bread", "tin", "shoes"),
                   Array("Unhappy", "small", "scarlet", "kingly", "bright", "sad", "spring"),
                   Array("Afraid", "pleased", "goodness", "tired", "warm", "frightened", "horse"),
                   Array("Near", "alive", "close", "happy", "stiff", "post", "busy"),
                   Array("View", "sight", "cost", "rub", "store", "jolt", "some"),
                   Array("Continue", "clash", "tilt", "read", "clutter", "bewail", "keep on"),
                   Array("Startle", "offer", "dimple", "frighten", "begin", "trim", "tailor"),
                   Array("Perfume", "scent", "legde", "tower", "box", "oath", "pouch"),
                   Array("Ache", "screen", "pain", "boom", "tree", "prize", "land"),
                   Array("Rage", "crease", "invite", "rain", "love", "anger", "hoist"),
                   Array("Squabble", "saw", "bubble", "mold", "lift", "photo", "quarrel"),
                   Array("Connect", "join", "lace", "flint", "field", "bean", "accident"),
                   Array("Provide", "harmonize", "hurt", "annoy", "divide", "commit", "sepply"),
                   Array("Brag", "choose", "hope", "lag", "boast", "stone", "jerk"),
                   Array("Shrivel", "linger", "volunteer", "shiver", "heed", "wither", "haunt"),
                   Array("Mingle", "interfere", "mix", "gamble", "press", "declare", "remark"),
                   Array("Stance", "partition", "glance", "position", "fixed", "slope", "grief"),
                   Array("Verify", "dedicate", "chastise", "correct", "confirm", "change", "purify"),
                   Array("Formidable", "unexpired", "feasible", "tremendous", "ravishing", "orderly", "remembrance"),
                   Array("Thrive", "think", "thrash", "blame", "try", "reap", "flourish"),
                   Array("Docile", "meek", "dominant", "careless", "passionate", "homely", "dumb"),
                   Array("Virile", "demanding", "concise", "vulgar", "familar", "manly", "barbarous"),
                   Array("Surmount", "mountain", "concede", "appease", "overcome", "descend", "snub"),
                   Array("Sultry", "instinctive", "sulky", "trivial", "solid", "severe", "muggy"),
                   Array("Criterion", "superior", "certitude", "clarion", "critic", "standard", "crisis"),
                   Array("Latent", "delayed", "potential", "ingenious", "discharged", "overburdened", "hostile"),
                   Array("Dwindle", "swindle", "linger", "diminish", "pander", "wheeze", "compare"),
                   Array("Construe", "prophesy", "contradict", "scatter", "interpret", "collect", "anneal"),
                   Array("Efface", "delete", "disgust", "adjoin", "rotate", "mark", "ascend"),
                   Array("Trumpery", "etiquette", "worthless", "amusement", "heraldry", "highest", "final"),
                   Array("Perpetrate", "appropriate", "propriate", "commit", "control", "deface", "pierce"),
                   Array("Glower", "scowl", "disguise", "aerate", "shine", "gloat", "extinguish"));
$answers = Array(4, 5, 5, 2, 1, 6, 3, 1, 2, 5, 6, 1, 6, 4, 3, 2, 3, 4, 3, 6, 3, 5, 4, 6, 3, 2, 3, 4, 1, 2, 3, 3);

?>

$(document).ready(function(){
    psychtools.initialize();
    psychtools.add_page(intro);
    psychtools.add_page(practice);
    psychtools.add_page(feedback);
<?php foreach ($questions as $i => $question) {
    $id = $i+1; ?>
        page = new Page("question_<?php echo $id; ?>", true, "<?php echo $question; ?>");
        page.correct_answer = <?php echo $answers[$i]; ?>;
        psychtools.add_page(page);
<?php
}
?>
    psychtools.add_page(thanks);
    psychtools.add_page(intro);
    psychtools.enable_autosave();
    psychtools.begin();
});

function load_slide_thanks() {
    psychtools.redirect(REDIRECT_URL, true);
}

_total_incorrect = 0;
function submit_page(response) {
    if (!response) return false;
    cur = psychtools.current_page();
    cur.response = response;

    /*Quit if more than four wrong in a row*/
    if (cur.correct() == true)
        _total_incorrect=0;
    else
        _total_incorrect++;
    if (_total_incorrect >= 4) 
        psychtools.override_next_page("last_slide");

    psychtools.advance_slide();
}

function load_slide_feedback() {
    if (psychtools.current_page().prev().correct() == true) 
        $('.incorrect').hide();
    else
        $('.correct').hide();
}

</script>
<link rel="stylesheet" type="text/css" href="../psychtools2/psychtools2.css" />
<link rel="stylesheet" type="text/css" href="vocab.css" />
</head>
<body>

<div class="slide" id="slide_inst1">
<div class="content">
<div class="instructions">
This is a vocabulary activity. All you have to do is find the word in
the answer choices which is closest in meaning to the word at the top
of the screen. When you have found the answer, use your mouse to
select it.

This activity was made for adults so you may not know all the
words. If you do not know the meaning of a word, you may guess or
answer "I don't know."  You will not be graded on this so just do your
best.
</div>
<P>
<div class="instructions">Press the space bar to continue</div>
</div>
</div>

<div class="slide" id="slide_practice">
<div class="content">
<div class="instructions">
Here is an example:
<div style="margin-top: 10px;">Cap</div>
<div class="questions">
<input type="radio" name="prac" id="practice_1" value="1"><label for="practice_1"> splash</label> <br />
<input type="radio" name="prac" id="practice_2" value="2"><label for="practice_2"> hat</label> <br />
<input type="radio" name="prac" id="practice_3" value="3"><label for="practice_3"> leg</label> <br />
<input type="radio" name="prac" id="practice_4" value="4"><label for="practice_4"> ball</label> <br />
<input type="radio" name="prac" id="practice_5" value="5"><label for="practice_5"> smoke</label> <br />
<input type="radio" name="prac" id="practice_5" value="6"><label for="practice_5"> mill</label> <br />
<input type="radio" name="prac" id="practice_idk" value="idk"><label for="practice_idk"> I don't know</label>
</div>
<br />
<br />
<button class="continuebutton" onclick="submit_page($('input:radio[name=prac]:checked').val())">Continue</button>
</div>
</div>
</div>

<div class="slide" id="slide_feedback">
<div class="content">
<div class="instructions">
<div class="correct">
Great job! The correct answer is <em>hat</em>, which is the closest in meaning to <em>cap</em>
</div>
<div class="incorrect">
Oops! The correct answer is <em>hat</em>, which is the closest in meaning to <em>cap</em>
</div>
</div>
<P>
<div class="instructions">Press the space bar to continue.</div>
</div>
</div>



<?php 
//Create a question slide from a string
foreach ($questions as $i => $question) {
$id = $i + 1;
?>
<div class="slide" id="slide_question_<?php echo $id; ?>">
<div class="content">
<div class="instructions">
<div><?php echo $question[0]; ?></div>
<div class="questions">
<?php for($j=1; $j<=6; $j++) { /*Each response option*/ ?>
<input type="radio" id="response<?php echo $id+'_'+$j; ?>" name="response<?php echo $id; ?>" value="<?php echo $j; ?>"><label for="response<?php echo $id+'_'+$j; ?>"><?php echo $question[$j]; ?></label> <br />
<?php } ?>
<input type="radio" id="response<?php echo $id; ?>_idk" name="response<?php echo $id; ?>" value="idk"><label for="response<?php echo $id; ?>_idk">I don't know</label> 
</div>
<br />
<br />
<button class="continuebutton" onclick="submit_page($('input:radio[name=response<?php echo $id; ?>]:checked').val())">Continue</button>
</div>
</div>
</div>
<?php
}
?>

<div class="slide" id="slide_thanks">
<div class="content">
<div class="instructions">
Now it is time to do a different activity.
Press the spacebar to read the activity directions.
</div>
</div>
</div>

</body>
</html>

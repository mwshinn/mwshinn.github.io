<?php
//db.php
//Database functions
require_once('settings.php');
if(strtolower($db_type) == 'mysql')
	require('db.mysql.php');
else if(strtolower($db_type) == 'flatfile')
	require('db.flatfile.php');
else if(strtolower($db_type) == 'sqlite')
	require('db.sqlite.php');
<?php
//draw.php
require_once('settings.php');
//require_once('languages/'.$desired_language);
function draw_areajavascript()
{
	?>

	<?php
}


function draw_css()
{
	?>
	<link rel="stylesheet" href="main.css" />
	<link type="text/css" href="styles/smoothness/jquery-ui-1.7.1.custom.css" rel="Stylesheet" />	
	<?php
}

function draw_smilies()
{
	global $enable_smileys;
	if($enable_smileys):
	?>
	<img src="img/1.gif" onclick="form1.message.value+=':]';form1.message.focus();<?php if($lighton==true) echo 'inc();'; ?>">&nbsp;&nbsp;&nbsp;
	<img src="img/2.gif" onclick="form1.message.value+=':D';form1.message.focus();<?php if($lighton==true) echo 'inc();'; ?>">&nbsp;&nbsp;&nbsp;
	<img src="img/3.gif" onclick="form1.message.value+=':-\'';form1.message.focus();<?php if($lighton==true) echo 'inc();'; ?>">&nbsp;&nbsp;&nbsp;
	<img src="img/4.gif" onclick="form1.message.value+=':-o';form1.message.focus();<?php if($lighton==true) echo 'inc();'; ?>">&nbsp;&nbsp;&nbsp;
	<img src="img/5.gif" onclick="form1.message.value+='>:[';form1.message.focus();<?php if($lighton==true) echo 'inc();'; ?>">&nbsp;&nbsp;&nbsp;
	<img src="img/6.gif" onclick="form1.message.value+=':tv';form1.message.focus();<?php if($lighton==true) echo 'inc();'; ?>">&nbsp;&nbsp;&nbsp;
	<img src="img/7.gif" onclick="form1.message.value+='I:-)';form1.message.focus();<?php if($lighton==true) echo 'inc();'; ?>">&nbsp;&nbsp;&nbsp;
	<img src="img/8.gif" onclick="form1.message.value+=':(';form1.message.focus();<?php if($lighton==true) echo 'inc();'; ?>">&nbsp;&nbsp;&nbsp;
	<img src="img/9.gif" onclick="form1.message.value+=':cheerup';form1.message.focus();<?php if($lighton==true) echo 'inc();'; ?>">&nbsp;&nbsp;&nbsp;
	<img src="img/10.gif" onclick="form1.message.value+=':party';form1.message.focus();<?php if($lighton==true) echo 'inc();'; ?>">&nbsp;&nbsp;&nbsp;
	<img src="img/11.gif" onclick="form1.message.value+=':O';form1.message.focus();<?php if($lighton==true) echo 'inc();'; ?>">&nbsp;&nbsp;&nbsp;
	<img src="img/12.gif" onclick="form1.message.value+=':P';form1.message.focus();<?php if($lighton==true) echo 'inc();'; ?>">&nbsp;&nbsp;&nbsp;
	<img src="img/13.gif" onclick="form1.message.value+='8)';form1.message.focus();<?php if($lighton==true) echo 'inc();'; ?>">&nbsp;&nbsp;&nbsp;
	<img src="img/14.gif" onclick="form1.message.value+=':o';form1.message.focus();<?php if($lighton==true) echo 'inc();'; ?>">&nbsp;&nbsp;&nbsp;<br />
	<?php
	endif;
	if(!$enable_smileys):
	?>
	<!--Smileys would be here if your grumpy, stuffy, boring, good for nothing administrator would enable them...-->
	<?php
	endif;
}

function draw_newtopic()
{
	?>
	<h3><a href="#"><?php echo language('language_new_topic'); ?></a></h3>
	<div>
	<form id="newtopic" onsubmit="return sendoffnewtopic()">
	<input type="text" id="newtitle" name="newtitle" size="15" value="<?php echo language('language_title'); ?>" onclick="if(this.value=='<?php echo language('language_title'); ?>')this.value='';" />
	<?php echo language('language_color'); ?>: <input type="text" id="newcolor" class="color" name="newcolor" size="4" value="FF0000" />
	<input type='submit' id="submit" value="<?php echo language('language_send'); ?>" />
	</form>
	</div>
	<?php
}
function draw_upload()
{
	
}
function draw_language()
{
	
}
function draw_footer()
{
	?>
	<center>
	<font size="1"><?php 
	global $display_habfooter; 
	//If you want to comment this out, be my guest.  You do know, though, that you've just wasted
	//your time looking for it, and that you can turn it off in the admin section, right?
	if($display_habfooter) : ?><a href="http://BernsteinForPresident.com/software/the-hablator" target="_blank">The Hablator</a><?php endif; ?>
	<br>
	<a href="<?php global $site_url; ?>"><?php global $site_title; ?></a></font>
	</center>
	<?php
}
function draw_logout()
{
	?>
	<form action="index.php" method="post"><input type="hidden" name="logout" value="1" /><input type="submit" value="<?php echo language('language_logout'); ?>" /></form>
	<?php
}
function draw_refresh()
{
	?>
	<center><?php echo language('language_refresh_for_updates'); ?></center>
	<?php
}
function draw_languages($default='en')
{
	global $languages;
	foreach($languages as $code => $language)
	{
		$isdefault = ($code == $default) ? 'selected=\'selected\'' : '';
		echo "<option $isdefault value=\"$code\">$language</option>";
	}
}
function draw_logoutscript()
{
	?>
	function logout_user(userid)
	{
		if(confirm('Are you sure you would like to log this user out?'))
			$.post("functions.php?action=logoutuser", {userid: userid}, function(){$("#userlist").load("functions.php?action=getuserlist", function(){})});
	}
	<?php
}
function draw_deletetopicscript()
{
	?>
	
	<?php
}
function draw_uploadform()
{
	?>
	<h3><a href="#"><?php echo language('language_upload_files'); ?></a></h3>
	<div>
	<form id="uploadform" action="functions.php?action=uploadfile" method="post"  enctype="multipart/form-data">
	<input type="text" id="upload_title" name="upload_title" size="10" value="<?php echo language('language_title'); ?>" onclick="if(this.value=='<?php echo language('language_title'); ?>')this.value='';" /><br />
	<input type="file" id="upload_file" name="upload_file" size="4" /><br /><br />
	<input type="submit" id="go" value="<?php echo language('language_send'); ?>" />
	</form>
	<div id="outputforupload"></div>
	</div>
	<?php
}
function draw_adminfunctions()
{
	?>

	function showuploadresponse(data)
	{
		if(!data.success)
			alert(data.message);
		updatedownloads();
	}
	function beforesubmituploadform(formData, jqForm, options)
	{
		return true;
	}
	function delete_topic(topicid)
	{
		if(confirm('Are you sure you would like to delete this topic?'))
			$.post("functions.php?action=deletetopic", {topicid: topicid}, function(){updatetopics()});
	}
	function delete_upload(uploadid)
	{
		if(confirm('Are you sure you would like to delete this file?'))
			$.post("functions.php?action=deleteupload", {uploadid: uploadid}, function(){updatedownloads()});
	}
	function sendoffnewtopic()
	{
	
		ntl = document.getElementById('newtitle').value;
		ncl = document.getElementById('newcolor').value;
	
		$.post("functions.php?action=newtopic", {newtitle: ntl, newcolor: ncl}, function(result){if(result==1) window.location='logout.php'})
		document.getElementById('newtitle').value='';
		return false;	
	}
	function clearformfield()
	{
		this.value = '';
	}
	<?php
}
function draw_downloads()
{
	?>
	<h3><a href="#"><?php echo language('language_downloads'); ?></a></h3>
	<div id="downloads">
	<?php printdownloads(); ?>
	</div>
	<?php
}
function draw_jsheaders()
{
	?>
	<script type="text/javascript" src="lib/jquery-1.3.2.min.js"></script>
	<script type="text/javascript" src="lib/jquery-ui-1.7.1.custom.min.js"></script>
	<?php
}
function draw_adminjsheaders()
{
	?>
	<script type="text/javascript" src="lib/jscolor.js"></script>
	<script type="text/javascript" src="lib/jquery.forms.js"></script>
	<?php
}
function draw_adminforminitjs()
{
	?>
	$('#uploadform').ajaxForm({
		beforeSubmit: beforesubmituploadform,
		success: showuploadresponse,
		resetForm: true,
		dataType: 'json',
		target: '#uploadformupload'
	}); 
	<?php
}
function draw_newpostalertjs()
{
	global $newpost_alert, $title;
	if($newpost_alert): ?>
	<script type="text/javascript">
	mousemoved = false;
	windowfocused = true;
	usewindowfocused = false;
	number = 0;
	inprogress = 0;
	document.onmousemove = mousemoveregister;
	document.onfocus = function() { windowfocused = true; };
	document.onblur = function() { windowfocused = false; usewindowfocused = true; };

	function mousemoveregister()
	{
		mousemoved = true;
		//windowfocused = true;
	}
	function newpost_effect_marquee()
	{
		if(!windowfocused || !usewindowfocused)
		{
			mousemoved = false;
			inprogress++;
			if(inprogress == 1)
			{
				document.title = ' <?php echo str_replace("'", "\'", language('language_new_message')); ?>  ';
				newpost_effect_marquee_loop();
			}
		}
	}
	function newpost_effect_marquee_loop()
	{
		if(!mousemoved)
		{
			/*if(document.title == '* * * * *')
				document.title = '<?php echo str_replace("'", "\'", $title); ?>';
			else
				document.title = '* * * * *';*/
			document.title = document.title.substring(1) + document.title.substring(0, 1);
			window.setTimeout(newpost_effect_marquee_loop, 500);
		}
		if(mousemoved || (windowfocused && usewindowfocused))
		{
			mousemoved = false;
			inprogress = 0;
			document.title = '<?php echo str_replace("'", "\'", $title); ?>';
		}
	}
	function newpost_effect_flash()
	{
		if(!windowfocused || !usewindowfocused)
		{
			mousemoved = false;
			inprogress++;
			if(inprogress == 1)
				newpost_effect_flash_loop();
		}
	}
	function newpost_effect_flash_loop()
	{
		if(!mousemoved)
		{
			/*if(document.title == '* * * * *')
				document.title = '<?php echo str_replace("'", "\'", $title); ?>';
			else
				document.title = '* * * * *';*/
			if(number == 0)
				document.title = '<?php echo str_replace("'", "\'", $title); ?>';
			else if(number == 1)
				document.title = '<?php echo str_pad(' ', strlen(str_replace("'", "\'", $title))); ?>';
			else if(number == 2)
				document.title = '<?php echo str_pad(str_replace("'", "\'", language('language_new_message')), strlen($title)); ?>';
			else if(number == 3)
				document.title = '<?php echo str_pad(' ', strlen($title)); ?>';
			window.setTimeout(newpost_effect_flash_loop, 500);
			number++;
			if(number > 3)
				number = 0;
		}
		if(mousemoved || (windowfocused && usewindowfocused))
		{
			document.title = '<?php echo str_replace("'", "\'", $title); ?>';
			inprogress = 0;
		}
	}
	function newpost_effect_dialog()
	{
		if(!windowfocused || !usewindowfocused)
		{
			mousemoved = false;
			alert('<?php echo str_replace("'", "\'", language('language_new_message')); ?>');
		}
	}
	</script>
	<?php
	endif;
}
?>
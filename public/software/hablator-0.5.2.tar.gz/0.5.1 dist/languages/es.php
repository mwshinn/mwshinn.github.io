<?php
// Traducción por: Max Shinn (script_champ@BernsteinForPresident.com)
// Corregido por: Áureo Ares (aureo.ares@gmail.com)
define('current_language', 'es');

//Chat area
define('language_active_users', 'Usuarios activos');
// changed - define('language_current_topics', 'Temas actual');
// 'actuales' is the plural for 'actual'. In spanish adjetives also have singular/plural forms.
define('language_current_topics', 'Temas actuales');
// changed - define('language_new_topic', 'Nueva tema');
// 'tema' is masculine.
define('language_new_topic', 'Nuevo tema');
// changed - define('language_upload_files', 'Nuevo archivo');
// for 'upload' we use 'subir' (to go up). I suppose that you didn't find a good translation for upload so you used 'new file'.
define('language_upload_files', 'Subir archivo');
// changed - define('language_downloads', 'Archivos');
// for 'download' we use 'bajar' (to go down) or 'descargar' (to unload).
// for 'downloads' we usually say 'descargas'.
define('language_downloads', 'Descargas');
define('language_refresh_for_updates', '(Refresca para actualizar)');
// changed - define('language_hide', 'Esconder');
// 'esconder' is correct, but in this context we prefer to say 'ocultar'.
define('language_hide', 'Ocultar');
define('language_send', 'Enviar');
// changed - define('language_logout', 'Terminar la sesión');
// for 'logout' we use 'salir' (to go out), 'desconectar' (disconnect) or 'cerrar sesión' (close the session).
// 'desconectar' is more frecuently used.
define('language_logout', 'Desconectar');
// changed - define('language_new_message', 'Nueva Mensaje');
// 'mensaje' is masculine.
define('language_new_message', 'Nuevo Mensaje');
//Chat area for moderators
define('language_color', 'Color');

//Login
define('language_moderator_password', 'Contraseña para Moderador (Opcional)');
define('language_compatibility_mode', 'Modo de Compatibilidad');
define('language_translation', 'Traducción');
define('language_name', 'Nombre');
define('language_password', 'Contraseña');
define('language_go', 'Ir');
define('language_please_enter_your_name', 'Introduzca su Nombre');
// changed - define('language_logout', 'Terminar la sesión');
// same reason as above.
define('language_logout', 'Desconectar');
// changed - define('language_options', 'Opciónes:');
// plural form of 'opción' doesn't have the accent in the 'o'. Long to explain, just trust me :P.
define('language_options', 'Opciones:');

//Other
// changed - define('language_logged_in', 'entré');
// 'entré' is first person singular (yo entré == I logged in). Third person is 'entró' (él entró == he logged in).
define('language_logged_in', 'entró');
define('language_logged_off', 'salió');
define('language_untitled', 'Sin Título');
define('language_translation_error', 'Problema con la traducción');
define('language_expired', 'Caducado');
// changed - define('language_new_message', 'Nueva Mensaje');
// 'mensaje' is masculine.
define('language_new_message', 'Nuevo Mensaje');
// changed - define('language_default', 'Por Omisión');
// your translation is correct. In fact, it's more correct than mine, but nobody say it. Many people wouldn't even understand it.
define('language_default', 'Por Defecto');
define('language_title', 'Título');
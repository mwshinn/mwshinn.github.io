<?php
//chat.php
defined('_HABLATOR') or die('No direct access');
?>
<html>
<title><?php echo $title; ?></title>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<?php draw_jsheaders(); ?>
<?php draw_newpostalertjs(); ?>
<?php moderatorshow('draw_adminjsheaders'); ?>

<script type="text/javascript">
//Darn it, IE!
<?php moderatorshow('draw_logoutscript'); ?>

if (!Array.prototype.indexOf)
{
  Array.prototype.indexOf = function(elt /*, from*/)
  {
    var len = this.length >>> 0;

    var from = Number(arguments[1]) || 0;
    from = (from < 0)
         ? Math.ceil(from)
         : Math.floor(from);
    if (from < 0)
      from += len;

    for (; from < len; from++)
    {
      if (from in this &&
          this[from] === elt)
        return from;
    }
    return -1;
  };
}

var hideboxes = new Array();
function sendoff()
{

	mes = document.getElementById('message').value;
	tpc = getCheckedValue(document.forms['topicform'].elements['topic']);
	$.post("functions.php?action=post", {message: mes, topic: tpc}, function(result){if(result==1) window.location='index.php'})
	//$.getScript('functions.php?action=newposts');
	document.getElementById('message').value = '';
	return false;
}
function temp() {return false; }
function movescroll(lines)
{
	if(document.getElementById("textareaspace").scrollTop != 0)
	{
		document.getElementById("textareaspace").scrollTop += <?php echo $line_height; ?>*lines;
	}
}
function countlines(string)
{
	try 
	{
		return(string.match(/[^\n]*\n[^\n]*/gi).length);
	} 
	catch(e) 
	{
		return 0;
	}
}
function getCheckedValue(radioObj) 
{
	if(!radioObj)
		return "";
	var radioLength = radioObj.length;
	if(radioLength == undefined)
	{
		if(radioObj.checked)
			return radioObj.value;
		else
			return "";
	}
	for(i=0; i < radioLength; i++) 
	{
		if(radioObj[i].checked) 
		{
			return radioObj[i].value;
		}
	}
	return "";
}
function setCheckedValue(radioObj, newValue) 
{
	if(!radioObj)
		return;
	var radioLength = radioObj.length;
	if(radioLength == undefined) 
	{
		radioObj.checked = (radioObj.value == newValue.toString());
		return;
	}
	for(i=0; i < radioLength; i++) 
	{
		radioObj[i].checked = false;
		if(radioObj[i].value == newValue.toString()) 
		{
			radioObj[i].checked = true;
		}
	}
}
function topichide(topic)
{
	if(document.getElementById('hidetopic'+topic).checked)
	{
		$(".topic"+topic).addClass('displaynone');
		if(hideboxes.indexOf(topic) == -1) hideboxes = hideboxes.concat(topic);
	}
	else
	{
		$(".topic"+topic).removeClass('displaynone');
		if(hideboxes.indexOf(topic) != -1) hideboxes.splice(hideboxes.indexOf(topic), 1);
	}
}
function topichidefast(topic)
{
	if(document.getElementById('hidetopic'+topic).checked)
	{
		$(".topic"+topic).addClass('displaynone');
	}
	else
	{
		$(".topic"+topic).removeClass('displaynone');
	}
}
function updatetopics()
{
	tpc = getCheckedValue(document.forms['topicform'].elements['topic']);
	$("#topics").load("functions.php?action=topics", function(){
		document.getElementById('topic'+tpc).checked = 1;
		for(i=0; i < hideboxes.length; i++)
		{
			document.getElementById('hidetopic'+hideboxes[i]).checked = true;
		}
//		hideboxes.forEach(function(val, valid){
//			document.getElementById('hidetopic'+val).checked = true;
//		});	
	});
}
function updatedownloads()
{
	$("#downloads").load("functions.php?action=downloads");
}
/*function repeat()
{
	//Function to be called
	setTimeout("repeat()",2000);
}*/
function updatecallback(data)
{
	if (data)
	{
		if(data == '<!--null-->')
			window.location = 'index.php';
		for(i=0; i < hideboxes.length; i++)
		{
			data = data.replace(new RegExp('topic'+hideboxes[i], "g"), 'topic'+hideboxes[i]+' displaynone');
			//document.getElementById('hidetopic'+hideboxes[i]).checked = true;
		}
		$("#textareaspace").prepend(data);
		//$("#textareaspace").html(data+$("#textareaspace").html());
		movescroll(countlines(data));
		<?php global $message_notification; $message_notification = strtolower($message_notification); if(strtolower($message_notification) != 'none') echo "newpost_effect_$message_notification();"; ?>
	}
}
<?php moderatorshow('draw_adminfunctions'); ?>
$(document).ready(function() 
{
	$("#sidebar").accordion({ fillSpace: true });
	document.getElementById('message').focus();
	<?php if($lighton == true) echo "checkinc();\n"; ?>
	$.get('functions.php?action=newposts', function(data){$('#textareaspace').prepend(data+"\n");});
	window.setInterval('$.get("functions.php?action=newposts", updatecallback);', <?php echo $posts_updateperiod; ?>);
	window.setInterval('$("#userlist").load("functions.php?action=getuserlist", function(){});', <?php echo $userlist_updateperiod; ?>);
	window.setInterval('updatetopics()', <?php echo $userlist_updateperiod; ?>);
	window.setInterval('updatedownloads()', <?php echo $userlist_updateperiod; ?>);
	$("a#userlistlink").click(function() 
	{
		$(this).children("img").toggle();
		$(this).next("div#userlist").slideToggle("fast");
		return false;
	});
	<?php moderatorshow('draw_adminforminitjs'); ?>
});
</script>
<?php draw_css(); ?>
</head>
<body>
<?php if($lighton == true) echo '<script type="text/javascript" src="lib/light.js"></script>'; ?>

<h2 style="text-align: center;" class="ui-state-default"><?php echo idtouser(md5(session_id())); ?> <?php if(ismoderator()) echo '(Moderator)'; ?> - <?php echo $title; ?></h2>

<center><?php draw_logout(); ?></center>
<br />
<form name="form1" id="form1" action='functions.php?action=post' method='post' autocomplete="off" onsubmit="return sendoff()"> 
<?php draw_smilies(); ?>
<input type="text" id="message" class="ui-widget" name="message" <?php if($message_limit != 0) echo 'maxlength="'.$message_limit.'" '; if($lighton == true) echo 'onkeydown="inc()"'; ?> /><input class="ui-widget" type='submit' id="submit" value="<?php echo language('language_send'); ?>" />
</form>
<br>


<div id='textareaspace' style="line-height: <?php echo $line_height; ?>px; height: <?php echo $line_height*$history_lines; ?>"><?php echo compat_getposts(); ?></div>
<div id="sidebar" class="sidebar">
<h3><a href="#"><?php echo language('language_active_users'); ?></a></h3>
<div id="userlist"><?php loadusers(); ?></div>
<h3><a href="#"><?php echo language('language_current_topics'); ?></a></h3>
<div>
<form id="topicform">
<div id="topics"><?php printtopics(); ?></div>
</form>
</div>
<?php moderatorshow('draw_newtopic'); ?>
<?php if($allow_uploads) moderatorshow('draw_uploadform'); ?>
<?php if($allow_uploads) draw_downloads(); ?>
</div>
<br>
<br>
<?php draw_footer(); ?>
<script type="text/javascript">
</script>
</html>

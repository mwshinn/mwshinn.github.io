<?php
/********************
The Hablator
Author: Max Shinn (script_champ@BernsteinForPresident.com)
http://bernsteinforpresident.com/software/the-hablator
Version: 0.5
Release Date: 6/24/2009
License: GPLv3
********************/
//Stupid caching
header("Cache-Control: no-cache, must-revalidate");
header("Expires: Sat, 26 Jul 1997 05:00:00 GMT");
header('Content-Type: text/html; charset=utf-8'); 
require_once("settings.php");
require_once('ffabstraction.php');
db_init();
require_once('draw.php');
require_once('language.php');
session_start();


include("settingsarray.php");
//Log the user in?
if(trim($_POST['nameofperson']) != '' && !loggedin() && ($global_password == NO_PASSWORD || md5(md5($_POST['password'])) == $global_password))
{
	purgeoldusers();
	$theirname = trim(stripslashes($_POST["nameofperson"]));

	//Make sure there is no html in the username
	$theirname = str_replace('<', '&lt;', $theirname);
	$theirname = str_replace('>', '&gt;', $theirname);

	$ismod = (md5(md5($_POST['moderator'])) == $moderator_password && $moderator_password != NO_PASSWORD) ? true : false;

	//Register the user
	//Note to self: this used to use the "or" statement
	$theirid = adduser($theirname, $ismod);
	if(!$theirid)
		die("Error assigning user name/id");

	//$_SESSION["bfptalkid"] = $theirid;
	//$_SESSION['sessionlastping'] = time();
	
	//Alert everyone that you logged in.
	postalert(idtouser(md5($theirid)).' '.language_logged_in);

	//Log this user, if the admin desires
	if($enable_user_logging == true)
	{
		$agent = $_SERVER["HTTP_USER_AGENT"];
		$ip  = $_SERVER['REMOTE_ADDR'];
		$complete = "<b>".idtouser(md5($theirid))."</b><i> (".$ip.", or ".gethostbyaddr($ip).")</i><b> logged on at </b><i>".date('h:i A')."</i><b> on </b><i>".date('m/d/Y')."</i><b> with the user agent </b><i>".$agent."</i><br>\n";
		$complete = str_replace(' ', '&nbsp;', $complete);
		$file = fopen("log.html", "a");
		fwrite($file, $complete);
	}
	

}
//Log the user out?
//Note to self: this included  || updatesession() == false
//so was this: || getlastping() + $logout_timeout < time()
else if($_POST['logout'])
{
	$name = idtouser(md5(session_id()));
	
	//Un-register the user
	removeuser(md5(session_id()));
	
	
	//Alert everyone
	if($name !== '') postalert($name.' '.language_logged_off);
	
	//Clean up
	session_unset();
	setcookie(session_name(), "", time() - 3600, "/");
	session_destroy();
	purgeoldposts();
}
//Figure out what to display!
if(loggedin() && !$_POST['compatibility'] && !iscompat())
	include('views/chat.php');
else if(loggedin() && ($_POST['compatibility'] || iscompat()))
	include('views/compatchat.php');
else
	include('views/login.php');
?>
<?php
define('_HABLATOR', '0.5');

$ini = parse_ini_file('settings.ini', true);
foreach($ini as $inisub1)
{
	foreach($inisub1 as $title2 => $inivalue2)
	{
		$$title2 = $inivalue2;
	}
}
?>
<?php
//functions.php
/*This executes functions passed by get variables*/

//Dang you, IE!  The line below took me weeks to figure out!
header("Cache-Control: no-cache");
session_start(); 


$action = $_GET['action'];
require_once('ffabstraction.php');
require_once('settings.php');
require_once('language.php');

if($action == 'getuserlist')
{
	require_once('ffabstraction.php');

	loadusers(md5(session_id()));
}
else if($action == 'newposts')
{
	session_start(); 
	if(!loggedin())
	{
		die('<!--null-->');
	}
	
	checkposts();
}
//be careful with this - it could ruin unicode support
else if($action == 'post')
{
	require("settings.php");
	include_once('ffabstraction.php');
	include('lib/autolink.php');
	session_start();
	$name = idtouser(md5(session_id()));
	//this line is bad, change it back to POST
	//$message = utf8_decode($_REQUEST['message']);
	$message = $_POST['message'];
	$topic = $_POST['topic'];
	if(!$topic) $topic = 1;
	if(trim($message) === '')
		exit();

	if($name != "")
	{
	
		//See if there is any html or a newline
		$message = str_replace('<', '&lt;', $message);
		$message = str_replace('>', '&gt;', $message);	
		$message = str_replace("\n", ' ', $message);
		//$message = htmlentities(stripslashes($message));
		$message = stripslashes($message);

		autolink($message);

		//No swearing!
		if($use_badword_filter == true)
		{
			$badwords = explode(',', $badword_words);
			foreach($badwords as $badword)
			{
				$replacement = str_pad('', strlen(chop($badword)), '*');
				$replacement{0} = substr(chop($badword), 0, 1);
				$replacement{strlen($replacement)-1} = substr(chop($badword), strlen(chop($badword))-1, 1);
				$message = str_ireplace(chop($badword), $replacement, $message);
			}
		}
	
		//Replace the smiley symbols with the actual smilies
		$symbols = array(':]', ':D', ':-\'', ':-o', '&gt;:[', ':tv', 'I:-)', ':(',':cheerup', ':party', ':O', ':P', '8)', ':o', ':)');
		$replacements = array('<img src="img/1.gif" alt=":]">', '<img src="img/2.gif" alt=":D">', '<img src="img/3.gif" alt=":-\'">', '<img src="img/4.gif" alt=":-o">', '<img src="img/5.gif" alt=">:[">', '<img src="img/6.gif" alt=":tv">', '<img src="img/7.gif" alt="I:-)">', '<img src="img/8.gif" alt=":(">', '<img src="img/9.gif" alt=":cheerup">', '<img src="img/10.gif" alt=":party">', '<img src="img/11.gif" alt=":O">', '<img src="img/12.gif" alt=":P">', '<img src="img/13.gif" alt="8)">', '<img src="img/14.gif" alt=":o">', '<img src="img/1.gif" alt=":)">');
		if($enable_smileys) $message = str_replace($symbols, $replacements, $message);
		
		
		//Should I keep track of everything that has been said?
		if($enable_history_logging == true)
		{
			$logmessage = $message;
			$userlanguage = getlanguage();
			$isme = false;
			if(substr($logmessage, 0, 4) == '/me ')
			{
				$logmessage = substr($logmessage, 3);
				$isme = true;
			}
			global $desired_language;
			$logmessage = ($userlanguage == $desired_language) ? $logmessage : translate($logmessage, $userlanguage, $desired_language);
			$logpoststyle = getstyle($topic);
			$tologtext = '';
			if($isme) 
				$tologtext = "<b><div class=\"topic$topic\" style=\" $logpoststyle\">$name ".$logmessage."</div></b>\n";
			else 
				$tologtext = "<div class=\"topic$topic\"><b>$name</b>: <span style=\"$logpoststyle\">$logmessage</span></div>\n";
			$file = fopen('history.html', "a");
			fwrite($file, $tologtext);
			fclose($file);
		}
		
		
		/*//Write the complete message to the file!	
		$fsize=filesize("message.txt");
		$file=fopen('message.txt', "r");
		$filecontents="";
		for($i=1; $i<=$history_lines-1; $i++)
		{
			$filecontents.=fgets($file);
		}	
		$file=fopen('message.txt', "w");
		$complete="<b>".stripslashes($name)."</b>:  ".stripslashes($message)."<br>\n"."$filecontents";
		fwrite($file, $complete);
		fclose($file);*/
		//TMP
		if(post($message, $topic) == 1) header('Location: index.php?logout=1');
		echo '0';
	}
	else echo("1");
}
else if($action == 'light')
{
	$sender = $_POST["sender"];

	//Mode 1: Makes sure the file is set to "typing" (1), and then returns 1
	if($sender == 1)
	{
		settyping(true);
		echo gettypingstring();
	}
	
	//Mode 2: Makes sure the file is set to "not typing" (2), and then returns 2
	else if($sender == 2)
	{
		settyping(false);
		echo gettypingstring();
	}
	
	//Mode 3: Returns typing or not typing (1 or 2)
	else if($sender == 0)
	{
		echo gettypingstring();
	}
	else
	{
		die("Error!  Please contact your server admin!");
	}
}
//moderators only!
else if($action == 'newtopic')
{
	if(!ismoderator())
		die("Moderators only");
	//Change this!  No magic allowed!
	$title = $_REQUEST['newtitle'];
	$color = $_REQUEST['newcolor'];
	if(!$color) $color = 'black';
	$style = "color: $color;";
	echo '0';

	//Strip out bad stuff from topic titles
	$title = str_replace('<', '&lt;', $title);
	$title = str_replace('>', '&gt;', $title);	
	$title = str_replace("\n", ' ', $title);
	$title = stripslashes($title);

	if($title)
		newtopic($title, $style);
}
else if($action == 'topics')
{
	require_once('settings.php');
	printtopics();
}
else if($action == 'logoutuser')
{
	if(ismoderator())
		removeuser($_POST['userid']);
}
else if($action == 'deletetopic')
{
	if(ismoderator())
		removetopic($_POST['topicid']);
}
else if($action == 'downloads')
{
	printdownloads();
}
else if($action == 'uploadfile')
{
	if(!ismoderator())
		die(json_encode(array('message' => 'You must be a moderator')));
	require_once('settings.php');
	$filetypes = explode(',', $upload_filetypes);
	$fileparts = explode('.', $_FILES['upload_file']['name']);
	$fileext = $fileparts[sizeof($fileparts) - 1];
	$fileid =  substr(md5(rand().time()), 0, 8);
	if(!$fileext)
		die(json_encode(array('message' => 'Sorry, that file was too big!')));

	if(!in_array($fileext, $filetypes))
		die(json_encode(array('message' => 'Not a valid upload type')));

	move_uploaded_file($_FILES['upload_file']['tmp_name'], "uploads/$fileid.$fileext");

	//Strip out bad stuff from file titles
	$filetitle = ($_POST['upload_title']) ? $_POST['upload_title'] : language('language_untitled');
	$filetitle = str_replace('<', '&lt;', $filetitle);
	$filetitle = str_replace('>', '&gt;', $filetitle);	
	$filetitle = str_replace("\n", ' ', $filetitle);
	$filetitle = stripslashes($filetitle);

	//Save everything
	saveupload($fileid, $filetitle, $fileext);


}
else if($action == 'deleteupload')
{
	if(ismoderator())
		removeupload($_REQUEST['uploadid']);

}
else if($action == 'download')
{
	$name = '';
	$name = getuploadname($_GET['file']);
	if(!file_exists('uploads/'.$name))
		die("No file with the name $name exists!");
	$ext = getuploadextension($_GET['file']);
	header("Content-type: application/force-download");
	header("Content-Transfer-Encoding: Binary");
	header("Content-length: ".filesize('uploads/'.$name));
	header("Content-disposition: attachment; filename=\"download.$ext\"");
	readfile('uploads/'.$name);
}
else if($action == 'whosonline')
{
	$type = $_GET['type'];
	if($type == 'text')
	{
		echo getusercount();
	}
	else if($type == 'image')
	{
		header("Content-type: image/png");
		if(!function_exists('gd_info'))
			die('Please install GD!');
		$image = imagecreatefrompng('img/online.png');
		$color = imagecolorallocate($image, 0, 0, 0);
		$font = 'lib/mgopencanonicaitalic.ttf';
		$number = getusercount();
		imagettftext($image, 30, 0, 45, 50, $color, $font, $number);
		imagepng($image);
		imagedestroy($image);
	}

}
//Posting in compatibility mode
else if($action == 'compatpost')
{
	require("settings.php");
	include_once('ffabstraction.php');
	include('lib/autolink.php');
	session_start();
	$name = idtouser(md5(session_id()));
	//this line is bad, change it back to POST
	$message = utf8_decode($_REQUEST['message']);
	$topic = $_REQUEST['topic'];
	if(!$topic) $topic = 1;

	if($name != "")
	{
	
		//See if there is any html or a newline

		//$message=str_replace('<', '&lt;', $message);
		//$message=str_replace('>', '&gt;', $message);	
		$message = str_replace("\n", ' ', $message);
		$message = htmlentities(stripslashes($message));
		autolink($message);


		//No swearing!
		if($use_badword_filter == true)
		{
			$badwords = explode(',', $badword_words);
			foreach($badwords as $badword)
			{
				$replacement = str_pad('', strlen(chop($badword)), '*');
				$replacement{0} = substr(chop($badword), 0, 1);
				$replacement{strlen($replacement)-1} = substr(chop($badword), strlen(chop($badword))-1, 1);
				$message = str_ireplace(chop($badword), $replacement, $message);
			}
		}
	
		//Replace the smiley symbols with the actual smilies
		$symbols = array(':]', ':D', ':-\'', ':-o', '&gt;:[', ':tv', 'I:-)', ':(',':cheerup', ':party', ':O', ':P', '8)', ':o', ':)');
		$replacements = array('<img src="img/1.gif" alt=":]">', '<img src="img/2.gif" alt=":D">', '<img src="img/3.gif" alt=":-\'">', '<img src="img/4.gif" alt=":-o">', '<img src="img/5.gif" alt=">:[">', '<img src="img/6.gif" alt=":tv">', '<img src="img/7.gif" alt="I:-)">', '<img src="img/8.gif" alt=":(">', '<img src="img/9.gif" alt=":cheerup">', '<img src="img/10.gif" alt=":party">', '<img src="img/11.gif" alt=":O">', '<img src="img/12.gif" alt=":P">', '<img src="img/13.gif" alt="8)">', '<img src="img/14.gif" alt=":o">', '<img src="img/1.gif" alt=":)">');
		if($enable_smileys) $message = str_replace($symbols, $replacements, $message);
		
		
		//Should I keep track of everything that has been said?
		if($enable_history_logging == true)
		{
			$file = fopen('history.html', "a");
			fwrite($file, "<b>".stripslashes($name)."</b>:  ".stripslashes($message)."<br>\n");
			fclose($file);
		}
		
		
		/*//Write the complete message to the file!	
		$fsize=filesize("message.txt");
		$file=fopen('message.txt', "r");
		$filecontents="";
		for($i=1; $i<=$history_lines-1; $i++)
		{
			$filecontents.=fgets($file);
		}	
		$file=fopen('message.txt', "w");
		$complete="<b>".stripslashes($name)."</b>:  ".stripslashes($message)."<br>\n"."$filecontents";
		fwrite($file, $complete);
		fclose($file);*/
		post($message, $topic);
	}
	header('Location: index.php');
}
?>

<?php
//This carries out actions specified by admin.php
require("settingsarray.php");
require('settings.php');
define('NO_PASSWORD', '74be16979710d4c4e7c6647856088456');
session_start();
//Check the password
if($_SESSION['verified'] != true)
{
	die('Please go through admin.php');
}

//Create the ini file text in this variable
$complete = "";
foreach($settingsarray as $title1 => $subarray1)
{
	$complete .= "[$title1]\n";
	foreach($subarray1 as $title2 => $subarray2)
	{
		$value = stripslashes($_POST[$title2]);

		//Security
		if($subarray2['type'] == 'command')
		{
			if(strpos($value, '..') !== false)
				die('Error - please enter a valid entry');
		}

		if($subarray2['type'] == 'bool')
		{
			if($value == 'on') $value = '1';
			else if($value == '') $value = '0';
		}
		//Main settings setter :)
		else if($value == '')
		{
			if($$title2) 
				$value = $$title2;
			else
				$value = $subarray2['default'];
		}
		else if($subarray2['type'] == 'password')
		{
			$value = md5(md5($value));
		}
		if($subarray2['type'] == 'password')
		{
			if($_POST[$title2.'_none'])
				$value = NO_PASSWORD;
		}
		$complete .= ";{$subarray2['description']} \n$title2 = $value\n";
	}
	$complete .= "\n";
}
$file = fopen("settings.ini", "w");
fwrite($file, $complete);
fclose($file);
?>
<h1>Success!</h1>
<a href="index.php">Go home</a><br />
<a href="admin.php">Go back to the admin section</a>
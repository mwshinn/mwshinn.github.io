#!/usr/bin/python
#beep.py
from getopt import gnu_getopt
from math import ceil
import sys

#BUGS
#The fifth always goes up instead of down
#Add relative and absolute mode
#Screen flashing effects?

#SYNTAX IS AS FOLLOWS:
#Capital letters are note names.  Their values go from middle C to the octave above that
#After this, add # or b if necessary
#Next, for every ' or , the note will be raised/lowered an octave
#Now for duration: a number after a note makes that note 1/x beats long
#A dash extends the previous note for another beat.  
#A dash followed by a number works the same way as a note followed by a number
#Underscores are rests
#All other characters are ignored, and can be used for formatting.

usage_help = """Usage: beep.py [OPTION] ... INPUT
  or:  beep.py [OPTION] ... -o OUTPUT INPUT
Compile INPUT into a bash script using the BEEP command and play it, or write it to OUTPUT

Mandatory arguments to long options are mandatory for short options too.
  -c,  --colors             Add a screen color special effect to the song
  -m,  --mode=a,r           Set the starting mode to Absolute (a) or Relative (r)
  -t,  --tempo=TEMPO        Set the starting tempo to TEMPO
  -o,  --output=OUTPUT      Output the bash script to the file OUTPUT
  -?,  --help               Display this help and exit

Report bugs to <admin@bernsteinforpresident.com>"""

#Define the notes
frequencies = {1: 261.626, 2: 277.183, 3: 293.665, 4: 311.127, 5: 329.628, 6: 349.228, 7: 369.994, 8: 391.995, 9: 415.305, 10: 440.000, 11: 466.164, 12: 493.883, -1: 1}
#noteno = {1: "C", 2: "Cis", 3: "D", 4: "Dis", 5: "E", 6: "F", 7: "Fis", 8: "G", 9: "Gis", 10: "A", 11: "Ais", 12: "B"}
noteno = {"c": 1, "cis": 2, "d": 3, "dis": 4, "e": 5, "f": 6, "fis": 7, "g": 8, "gis": 9, "a": 10, "ais": 11, "b": 12, "r": -1}

#store tuplets in song as (note number, note duration, octave, frequency) # (The only current special function is a gliss
notes = []


#Some general defines
outputfile = ""
tempo = 0
mode = ""
colors = False

def get_tempo():
	#tempo = int(input("What tempo (BPM) would you like? "))
	#return tempo
	return 120
def get_mode():
	#a = "a"
	#r = "r"
	#mode = str(input("Would you like relative mode r or absolute mode a? "))
	#return mode
	return "r"

def display_error(error_text):
	print("ERROR IN SYNTAX: " + error_text)
	
def note_number(note_name):
	return noteno[note_name]
	#pass #This will look up a note number based on the letter

def note_name(number):
	pass #This will look up a note name based on the number
def set_mode(text):
	if text == "relative" or text == "r":
		return "r"
	elif text == "absolute" or text == "a":
		return "a"
	else:
		exit("Invalid mode: " + str(text))
def gliss(note1, note2):
	resolution = 30
	returnstring = "beep "
	n = note1[1]/resolution
	step = (note2[3] - note1[3])/ceil(n) 
	i = 0
	while i <= n:
		if i != 0:
			returnstring += " -n "
		returnstring += " -f " + str(int(note1[3]+(i*step))) + " -l " + str(resolution)
		i += 1
	if i > n:
		returnstring += "  -n -f " + str(int(note2[3]-step)) + " -l " + str(1+(i-n))
	return returnstring
def tremolo(note1, note2):
	resolution = 50
	returnstring = "beep "
	n = note1[1]/resolution
	i = 0
	while i <= n:
		if i % 2:
			currentnote = note1
		else:
			currentnote = note2
		if i != 0:
			returnstring += " -n "
		returnstring += "-f " + str(int(currentnote[3])) + " -l " + str(resolution)
		i += 1
	return returnstring
#get command-line arguments
parsedoptions, options = gnu_getopt(sys.argv[1:], "o:t:m:c:?", ["output=", "tempo=", "mode=", "colors", "help"])
for optionname, optionvalue in parsedoptions:
	if optionname == "-o" or optionname == "--output":
		outputfile = str(optionvalue)
	elif optionname == "-t" or optionname == "--tempo":
		tempo = int(optionvalue)
	elif optionname == "-m" or optionname == "--mode":
		mode = set_mode(optionvalue)
	elif optionname == "-c" or optionname == "--colors":
		colors = True
	elif optionname == "-h" or optionname == "-?" or optionname == "--help":
		print usage_help
		exit()
if len(options) >= 1:
	inputfile = options[0]
else:
	exit(usage_help)
if tempo == 0:
	tempo = get_tempo()
if mode == "":
	mode = get_mode()


#File to read
file = open(inputfile, "r")
c = file.read(1)


#main loop
while c != "":
	if c.lower() in noteno: #Normal notes
		note = note_number(c.lower())
		duration = (60*1000)/tempo
		octave = 0

		c = file.read(1)
		
		#Sharps/flats
		if c == "i":
			c = file.read(1)
			if c == "s":
				c = "#"
		elif c == "e":
			c = file.read(1)
			if c == "s":
				c = "b"
		if c == "#":
			if note == 12:
				note = 1
			else:
				note += 1
			c = file.read(1)
		elif c == "b":
			if note == 1:
				note == 12
			else:
				note -= 1
			c = file.read(1)
			
		frequency = frequencies[note]


		if mode == "r": #Relative mode
			i = len(notes) - 1
			lastnote = -1
			lastoctave = 0
			#print "i is "+str(str(lastnote).isdigit())
			while lastnote == -1 and i >= 0:
				lastnote = notes[i][0]
				lastoctave = notes[i][2]
				print "whatever"
				i = i - 1
			octave = lastoctave
			print note
			print octave
				
			#now apply any changes requested
			while c == ",":
				octave = octave - 1 
				c = file.read(1)
			while c == "'":
				octave += 1
				c = file.read(1)
			if str(lastnote).isdigit():
				if note - lastnote >= 7 and lastnote != -1:
					octave = octave - 1
				if lastnote - note >= 7 and lastnote != -1:
					octave += 1
			
		elif mode == "a": #Absolute mode
			#now apply any changes requested
			
			while c == ",":
				octave = octave - 1 
				c = file.read(1)
			while c == "'":
				octave += 1
				c = file.read(1)
		else:
			exit("Invalid mode")



		#now apply the octaves
		for i in range(0, octave):
			frequency *= 2
		for i in range(octave, 0):
			frequency = frequency / 2

		#Durations
		if c.isdigit():
			duration = duration/int(c)
			c = file.read(1)
		
		if frequency == 0:
			frequency = 1
		notes.append((note, duration, octave, frequency))
		
	elif c == "-": #Continue the last note
		c = file.read(1)
		duration = (60*1000)/tempo
		if c.isdigit():
			duration = duration/int(c)
			c = file.read(1)
		notes[len(notes)-1] = (notes[len(notes)-1][0], notes[len(notes)-1][1] + duration, notes[len(notes)-1][2], notes[len(notes)-1][3])

	elif c == ".": #Shorthand for n -2, n2 -4, etc.
		notes[len(notes)-1] = (notes[len(notes)-1][0], notes[len(notes)-1][1] * 1.5, notes[len(notes)-1][2], notes[len(notes)-1][3])
		c = file.read(1)
		
	elif c == '\\': #Commands
		c = file.read(1)
		toset = ""
		tosetvalue = ""
		while c != "=" and c != " " and c != "\n":
			toset += c
			c = file.read(1)
		if c == "=":
			c = file.read(1)
			while c != " " and c != "\n":
				tosetvalue += c
				c = file.read(1)
		if toset.lower() == "tempo":
			tempo = int(tosetvalue)
		elif toset.lower() == "mode":
			mode = set_mode(tosetvalue)
		elif toset.lower() in ["absolute", "relative"]:
			mode = set_mode(toset)
		c = file.read(1)
	elif c == '~':
		notes.append(('~', 0, notes[len(notes)-1][2], notes[len(notes)-1][2]))
		c = file.read(1)
	elif c == '=':
		notes.append(('=', 0, notes[len(notes)-1][2], notes[len(notes)-1][2]))
		c = file.read(1)
	else:
		c = file.read(1)


	
complete = ""
i = 0
while i <= len(notes) - 1:
	if len(notes) >= i+2 and notes[i+1][0] == "~":
		complete += gliss(notes[i], notes[i+2])
		i += 1
	elif len(notes) >= i+2 and notes[i+1][0] == "=":
		complete += tremolo(notes[i], notes[i+2])
		i += 2
	else:	
		complete += "beep -f " + str(notes[i][3]) + " -l " + str(notes[i][1])
	if colors:
		if i % 7 == 0:
			complete += " && echo -e '\E[30;46m'&& clear "
		if i % 7 == 1:
			complete += " && echo -e '\E[30;48m'&& clear "
		if i % 7 == 2:
			complete += " && echo -e '\E[30;45m'&& clear "
		if i % 7 == 3:
			complete += " && echo -e '\E[30;44m'&& clear "
		if i % 7 == 4:
			complete += " && echo -e '\E[30;43m'&& clear "
		if i % 7 == 5:
			complete += " && echo -e '\E[30;42m'&& clear "
		if i % 7 == 6:
			complete += " && echo -e '\E[30;41m'&& clear "
	if(i != len(notes) - 1):
		complete += " && \n"
	i += 1
if colors:
	complete += " && echo -e '\E[30;49m' && clear" 
if outputfile:
	outputfile = open(outputfile, "w")
	outputfile.write(complete)
	outputfile.close()
else:
	from os import system
	print complete
	system(complete)


<?php
//code for the update system
//Please note: this is never actually used.  This is
//just the source code used on hablator-update.bernsteinforpresident.com
if($_GET['update'])
	header('Location: http://bernsteinforpresident.com/software/the-hablator');

$json_data = array
(
	'stable' => '0.5.1',
	'unstable' => '0.5'
);
$c_var = ereg_replace("[^A-Za-z0-9]", "", $_GET['c'] );
echo $c_var.'('.json_encode($json_data).');';
?>
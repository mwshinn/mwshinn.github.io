<?php
//language.php
require_once('ffabstraction.php');
require_once('habtranslate.php');

$lang = $_REQUEST['lang'];
if(!$lang)
{
	$posslang = getlanguage();
	if($posslang)
		$lang = $posslang;
	else
		$lang = $desired_language;
}

if(!convertlanguage($lang))
	die('That\'s not a valid language!');
if(is_file("languages/$lang.php"))
{
	require_once("languages/$lang.php");
}
else
{
	require_once("languages/$desired_language.php");
	$trans = new habtranslate();
}

function language($text)
{
	global $desired_language, $lang, $trans, $online_features;

	$totranslate = (@constant($text)) ? constant($text) : $text;
	if(current_language == $lang || !$online_features)
		return $totranslate;
	else
	{
		return translate($totranslate, $desired_language, $lang, $trans);
	}
}
function convertlanguage($lang)
{
	global $languages;
	return $languages[$lang];
}
function translate($text, $from, $to, &$transobject='')
{
	global $online_features;
	if(!$online_features) 
		return $text;
	if(!$transobject) {$transobject =  new habtranslate();}
	//Make sure they exist!
	if(!convertlanguage($from)) $from = 'en';
	if(!convertlanguage($to)) $to = 'en';
	$functiontitle = $from.'_to_'.$to;

	//try... catch... whatever...
	try
	{
		return $transobject->$functiontitle($text);
	}
	catch(Exception $e)
	{
		return language_translation_error;
	}
}
?>
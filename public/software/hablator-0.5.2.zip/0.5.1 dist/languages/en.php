<?php
// Translation by: Max Shinn (script_champ@BernsteinForPresident.com)
define('current_language', 'en');

//Chat area
define('language_active_users', 'Active users');
define('language_current_topics', 'Current topics');
define('language_new_topic', 'New topic');
define('language_upload_files', 'Upload files');
define('language_downloads', 'Downloads');
define('language_refresh_for_updates', '(Refresh the page for updates)');
define('language_hide', 'Hide');
define('language_send', 'Send');
define('language_logout', 'Logout');
define('language_new_message', 'New Message');
//Chat area for moderators
define('language_color', 'Color');

//Login
define('language_moderator_password', 'Moderator Password (Optional)');
define('language_compatibility_mode', 'Compatibility Mode');
define('language_translation', 'Translation');
define('language_name', 'Name');
define('language_password', 'Password');
define('language_go', 'Go');
define('language_please_enter_your_name', 'Please enter your name');
define('language_logout', 'Logout');
define('language_options', 'Options:');

//Other
define('language_logged_in', 'logged in');
define('language_logged_off', 'logged off');
define('language_untitled', 'Untitled');
define('language_translation_error', 'Translation Error');
define('language_expired', 'Expired');
define('language_new_message', 'New Message');
define('language_default', 'Default');
define('language_title', 'Title');
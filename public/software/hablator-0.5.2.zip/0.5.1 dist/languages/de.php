<?php
// -*- coding: utf-8 -*-
// Translation by: Benjamin Peterson (benjamin@python.org)
define('current_language', 'de');

//Chat area
define('language_active_users', 'Active Benutzern');
define('language_current_topics', 'Derzeitige Themen');
define('language_new_topic', 'Neues Thema');
define('language_upload_files', 'Feilen hinaufladen');
define('language_downloads', 'Download');
define('language_refresh_for_updates', '(Die Seite aktualisieren)');
define('language_hide', 'Verstecken');
define('language_send', 'Schicken');
define('language_logout', 'Abmelden');
define('language_new_message', 'Neue Nachricht');
//Chat area for moderators
define('language_color', 'Farbe');

//Login
define('language_moderator_password', 'Passwort der Bremssubstanz (Freiwillig)');
define('language_compatibility_mode', 'Verträglichkeitbetriebsart');
define('language_translation', 'Translation');
define('language_name', 'Name');
define('language_password', 'Passwort');
define('language_go', 'Anmelden');
define('language_please_enter_your_name', 'Geben Sie Ihren Name ein');
define('language_logout', 'Abmelden');
define('language_options', 'Einstellung:');

//Other
define('language_logged_in', 'angemeldet');
define('language_logged_off', 'abgemeldet');
define('language_untitled', 'Kein Titel');
define('language_translation_error', 'Fehler während Ubersetzung');
define('language_expired', 'Verfallen');
define('language_new_message', 'Neue Nachricht');
define('language_default', 'Vorgabe');
define('language_title', 'Titel');
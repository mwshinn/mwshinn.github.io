<?php
//admin.php

include("settingsarray.php");
include('settings.php');
include('draw.php');
include('language.php');
session_start();
$passwords = '';
define('NO_PASSWORD', '74be16979710d4c4e7c6647856088456');
define('update_url', 'http://update.bernsteinforpresident.com/hablator.php');

?>
<html>
<head>
<link rel="stylesheet" href="main.css" />
<script type="text/javascript" src="lib/jquery-1.3.2.min.js"></script>
<script type="text/javascript" src="lib/easyTooltip.js"></script>
<script type="text/javascript" src="lib/digitialspaghetti.password.min.js"></script>

<?php
if((md5(md5($_POST['adminpassword'])) != $admin_password || $admin_password == NO_PASSWORD) && $_SESSION['verified'] != true)
{
	?>
	</head><body>
	<h1>Administrator Login</h1>
	<form action="admin.php" method="post">
		Enter the password: <input type="password" name="adminpassword" id="adminpassword" />
		<input type="submit" name="sendoff" id="sendoff" value="Go" />
	</form></body>
	<?php
	exit();
}
else if(md5(md5($_POST['adminpassword'])) == $admin_password && $admin_password != NO_PASSWORD && $_SESSION['verified'] != true)
	$_SESSION['verified'] = true;

?>
<script type="text/javascript"> 
function confirmpasswords()
{
	<?php
	foreach($settingsarray as $subarray1)
	{
		foreach ($subarray1 as $title2 =>$subarray2)
		{
			if($subarray2['type'] == 'password')
			{
				?>
				if(document.getElementById('<?php echo $title2; ?>').value != document.getElementById('<?php echo $title2; ?>_conf').value) 
				{
					alert('Make sure the values in the <?php echo $subarray2['title']; ?> fields match!');
					return false;
				}
			<?php
			}
		}
	}
	?>
	return true;
}
function numberCheck(evt)
{
	var character = (evt.which) ? evt.which : event.keyCode
	if (character > 31 && (character < 48 || character > 57))
		return false;
	return true;
}
function disableinput(inputid)
{
	if(document.getElementById(inputid+'_none').checked)
	{
		document.getElementById(inputid).disabled = true;
		document.getElementById(inputid+'_conf').disabled = true;
	}
	else
	{
		document.getElementById(inputid).disabled = false;
		document.getElementById(inputid+'_conf').disabled = false;
	}
}
function help(helpid)
{
	alert(document.getElementById(helpid).title);
}
<?php if($online_features): ?>
	function updatecallback(jsondata)
	{
		currentversion = <?php echo _HABLATOR; ?>;
		updatetext = '';
		if(jsondata.stable != currentversion)
			updatetext = 'A new release of The Hablator is available.  <a href="<?php echo update_url; ?>?update=1">Download it now!</a>';
		else if(jsondata.unstable != currentversion)
			updatetext = 'A new unstable prerelease release of The Hablator is available.  You may or may not want to upgrade, based on your needs.  <a href="<?php echo update_url; ?>?update=1">Learn more!</a>';
		if(updatetext)
			$('#update_area').html(updatetext);
	}
<?php endif; ?>
$(document).ready(function() 
{
	$("div.subs").hide();
	$("a.title").click(function() 
	{
		$(this).children().children("img").toggle();
		$(this).next("div").slideToggle("fast");
		return false; 
	});
	$(".helpimage").easyTooltip();
	<?php if($online_features): ?>$.getJSON('<?php echo update_url; ?>?c=?', updatecallback);<?php endif; ?>
}); 
</script>
</head>
<h1>The Hablator Administrator Section</h1>
<body style="margin-left: 50px;">
<?php draw_logout(); ?>
<div id="update_area" name="update_area"></div>
<form action="adminactions.php" method="post" onsubmit="return confirmpasswords()">
<?php
foreach($settingsarray as $title1 => $subarray1)
{
	?>
	<a href="#" class="title"><h2><img src="img/triright.gif" class="tri"><img src="img/tridown.gif" style="display:none; border: none" class="tri"><?php echo $title1; ?></h2></a>
	<div class="subs">
	<?php
	foreach($subarray1 as $title2 => $subarray2)
	{
		if($subarray2['type'] == 'string')
		{
			?>
			<div class="options"><label for="<?php echo $title2; ?>"><?php echo $subarray2["title"]; ?>:</label> <input type="text" id="<?php echo $title2; ?>" name="<?php echo $title2; ?>" value="<?php if($$title2) echo $$title2; else echo $subarray2["default"]; ?>" /> <img src="img/questionmark.gif" class="helpimage" alt="[Help]" title="<?php echo $subarray2["description"]; ?>" /></div>
			<?php
		}
		if($subarray2['type'] == 'password')
		{
			?>
			<div class="options"><label for="<?php echo $title2; ?>"><?php echo $subarray2["title"]; ?>:</label> <input type="password" id="<?php echo $title2; ?>" <?php if($$title2 == NO_PASSWORD) echo 'disabled="disabled"'; ?> name="<?php echo $title2; ?>" value="" title="<?php echo $subarray2["description"]; ?>" /> <img src="img/questionmark.gif" class="helpimage" alt="[Help]" title="<?php echo $subarray2["description"]; ?>" /></div>
			<div class="options" style="padding-left: 30px;"><label for="<?php echo $title2; ?>_conf"><?php echo $subarray2["title"]; ?> (confirm):</label> <input type="password" id="<?php echo $title2; ?>_conf" <?php if($$title2 == NO_PASSWORD) echo 'disabled="disabled"'; ?> name="<?php echo $title2; ?>_conf" value="" title="Please confirm the password above." /></div>
			<?php if(!$subarray2['empty']): ?>
			<div class="options" style="padding-left: 30px;"><label for="<?php echo $title2; ?>_none">No <?php echo $subarray2["title"]; ?>:</label> <input type="checkbox" name="<?php echo $title2; ?>_none" <?php if($$title2 == NO_PASSWORD) echo 'checked="yes"'; ?> id="<?php echo $title2; ?>_none" onclick="disableinput('<?php echo $title2; ?>');" /></div>
			<?php endif;

			$passwords[] = $title2;
		}
		else if($subarray2['type'] == 'int')
		{
			?>
			<div class="options"><label for="<?php echo $title2; ?>"><?php echo $subarray2["title"]; ?>:</label> <input type="text" id="<?php echo $title2; ?>" name="<?php echo $title2; ?>" value="<?php if($$title2) echo $$title2; else echo $subarray2["default"]; ?>" title="<?php echo $subarray2["description"]; ?>" onkeypress="return numberCheck(event)" size="3" /> <img src="img/questionmark.gif" class="helpimage" alt="[Help]" title="<?php echo $subarray2["description"]; ?>" /></div>
			<?php
		}
		else if($subarray2['type'] == 'bool')
		{
			?>
			<div class="options"><label for="<?php echo $title2; ?>"><?php echo $subarray2["title"]; ?>:</label> <input type="checkbox" id="<?php echo $title2; ?>" name="<?php echo $title2; ?>" <?php if($$title2 == true) echo 'checked="yes"'; else if($$title2 == false) echo ''; else if($subarray2["default"] == true) echo 'checked="yes"'; else if($subarray2["default"] == false) echo '';  ?> title="<?php echo $subarray2["description"]; ?>" /> <img src="img/questionmark.gif" class="helpimage" alt="[Help]" title="<?php echo $subarray2["description"]; ?>" /></div>
			<?php
		}
		else if($subarray2['type'] == 'command')
		{
			?>
			<div class="options"><label for="<?php echo $title2; ?>"><?php echo $subarray2["title"]; ?>:</label> <select id="<?php echo $title2; ?>" name="<?php echo $title2; ?>" default="<?php if($$title2) echo $$title2; else echo $subarray2["default"]; ?>" title="<?php echo $subarray2["description"]; ?>">
			<?php
			foreach(eval($subarray2['command']) as $output)
			{
				if($output == $$title2)
					echo "<option value=\"$output\" selected=\"selected\">$output</option>";
				else
					echo "<option value=\"$output\">$output</option>";
			}
			?>
			</select> <img src="img/questionmark.gif" class="helpimage" alt="[Help]" title="<?php echo $subarray2["description"]; ?>" /></div>
			<?php
		}
	}
	?>
	</div>
	<?php
}
?>
<input type="submit" value="submit" />
</form>
<?php 
for($i = 0; $i < 7; $i++)
	echo '<br />';
?>
</body>
</html>

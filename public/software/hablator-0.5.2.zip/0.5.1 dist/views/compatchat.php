<?php
//chat.php
defined('_HABLATOR') or die('No direct access');
?>
<html>
<title><?php echo $title; ?></title>
<head>
<meta http-equiv="pragma" content="no-cache">
<meta http-equiv="expires" content="-1">
</head>
<body>

<h2><center><?php echo $title; ?></center></h2>

<center><?php draw_logout(); ?></center>
<?php draw_refresh(); ?>
<br />
<form name="form1" id="form1" action='functions.php?action=compatpost' method='post' autocomplete="off" onsubmit="return sendoff()"> 
<?php draw_smilies(); ?>
<input type="text" id="message" name="message" /><input type='submit' id="submit" value="<?php echo language('language_send'); ?>" /> 
</form>
<br>


<?php /*for($i=0; $i<$history_lines; $i++) echo "<div id='textarea".($i+1)."'>&nbsp;</div>\n";*/ ?>
<div id='textareaspace' style="line-height: <?php echo $line_height; ?>px; border: 1px solid #000;"><?php compat_getposts(); ?></div>
<br>
<br>
<?php draw_footer(); ?>

</html>

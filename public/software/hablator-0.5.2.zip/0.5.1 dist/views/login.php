<?php
//login.php
defined('_HABLATOR') or die('No direct access');
?>
<html>
<head>
<title><?php echo $title; ?></title>
<link rel="stylesheet" href="main.css" />
<script type="text/javascript" src="lib/jquery-1.3.2.min.js"></script>
</head>
<body>
<center>
<h1><?php echo $title; ?></h1>
<br>
<h2><?php echo language('language_please_enter_your_name'); ?></h2>
<br>
<br>
<br>
<br>
<form action="index.php" method="post" name="form1">
<label for="nameofperson"><?php echo language('language_name'); ?>:</label> <input type="text" <?php if($username_limit != 0) echo " maxlength=\"$username_limit\" ";
 ?> id="nameofperson" name="nameofperson"> <input type="submit" value="<?php echo language('language_go'); ?>">

<?php if($global_password != NO_PASSWORD) echo '<div>'.language('language_password').': <input type="password" name="password"></div>'; ?>
<br />
<br />
<a style="font-weight: bold;" href="#" onclick="$('div#options').toggle('fast')"><?php echo language('language_options'); ?></a>
<br />
<div id="options" style="display: none;">
<div><label for="moderator"><?php echo language('language_moderator_password'); ?>:</label><input type="password" name="moderator" id="moderator" /></div> 
<div><label for="compatibility"><?php echo language('language_compatibility_mode'); ?>:</label><input type="checkbox" name="compatibility" id="compatibility" checked /></div>
<?php if($online_features): ?>
	<div><label for="lang"><?php echo language('language_translation'); ?>:</label><select id="lang" name="lang"><?php draw_languages($lang); ?></select></div>
<?php endif; ?>
<?php if(!$online_features): ?>
	<input type="hidden" name="lang" id="lang" value="en" />
<?php endif; ?>

</div>
<br />
</form>
<br>
<br>
<br>
<br>
<br>
<br>
</center>
<?php draw_footer(); ?>
<script type="text/javascript">
<!--
document.getElementById('nameofperson').focus();
document.getElementById('compatibility').checked = false;
//-->
</script>

</body>
</html>
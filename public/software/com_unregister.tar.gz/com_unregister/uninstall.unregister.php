<?php
function com_uninstall() {
  echo "Unregister++ Successfully Uninstalled";
}
?>
<?php
function com_install() {
  echo "Unregister++ Successfully Installed";
}
?>
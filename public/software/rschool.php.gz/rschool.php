<?php
//options
$school_name = 'schoolXXX';
$url_prefix = 'http://127.0.0.1';
$file_name = 'rschool.php';

if($_GET['FileName'])
{
	header('Content-Disposition: attachment; filename='.$_GET['fileName']);
	exit();
}

$parts = split('/', $_SERVER['REQUEST_URI']);
$taskid = $parts[3];
$task = $parts[4];
$id = $parts[2];
$url = curl_init();
if($id == '')
{
	curl_setopt($url, CURLOPT_URL, 'http://www.rschooltoday.com/se3bin/clientschool.cgi?schoolname='.$school_name);
}
else if($id == 'dept')
{
	curl_setopt($url, CURLOPT_URL, 'http://www.rschooltoday.com/se3bin/clientschool.cgi');
}
else
{
	curl_setopt($url, CURLOPT_URL, 'http://www.rschooltoday.com/se3bin/clientgenie.cgi');
	curl_setopt($url, CURLOPT_POST, 1);
}
curl_setopt($url, CURLOPT_RETURNTRANSFER, true);
if($id == '')
{
}
else if($id == 'dept')
{
	curl_setopt($url, CURLOPT_POSTFIELDS, "statusFlag=goSite&siteSel=$taskid&schoolname=$school_name");
}
else if($task == '')
{
	curl_setopt($url, CURLOPT_POSTFIELDS, "statusFlag=goGenie&geniesite=$id&schoolname=$school_name");
}
else if($task == 'g5plugin')
{
	curl_setopt($url, CURLOPT_POSTFIELDS, "statusFlag=goGenie&geniesite=$id&myButton=$task&db=$taskid&schoolname=$school_name");
}



$page = html_entity_decode(htmlentities(curl_exec($url)), ENT_COMPAT, 'UTF-8');

curl_close($url);

$page = ereg_replace('<input type="button" value="Download" class="link" onClick\=\"javascript:download\(\'([^\']*)\',\'([^\']*)\'\);\">', '<a href="\1">Download</a>', $page);
$page = ereg_replace('<input type="button" value="&nbsp;View&nbsp;" class="link" onClick="window\.open\(\'([^\']+)\',\'FileOpen\',\'width=800,height=600,status,scrollbars,resizable,top=0,left=0\'\);">', '<a href=\'\1\' onclick="window.open(\'\1\',\'FileOpen\',\'width=800,height=600,status,scrollbars,resizable,top=0,left=0\'); return false;">View</a>', $page);
$page = str_replace('se3bin/../','', $page); 
$page = str_replace('/g5-bin/downloadFile.pl','http://rschooltoday.com/g5-bin/downloadFile.pl', $page); 
$page = ereg_replace('javascript:download4\(\'([^\']*)\',\'([^\']*)\'\)', 'http://rschooltoday.com/se3bin/download4.pl?FileName=\1&FileNameOrig=\2', $page);
$page = str_replace('../', 'http://www.rschooltoday.com/', $page);
$page = str_replace('javascript:goHome()', $url_prefix.'/'.$file_name, $page);
$page = str_replace('file://webwww/www/', 'http://www.district112.org/', $page);
$page = ereg_replace('javascript:goGenie\(([0-9]*)\)', $url_prefix.'/'.$file_name.'/\\1', $page);
$page = ereg_replace('javascript:goSite\(([0-9]*)\);', $url_prefix.'/'.$file_name.'/dept/\\1', $page);
$page = eregi_replace('javascript:genieNavLinkto\(\\\\"([0-9]+)__([Yn])__([0-9]+)\\\\"\)', $url_prefix.'/'.$file_name.'/\1', $page);

$page = eregi_replace('javascript:genieNavLinkto\(\\\\"([a-zA-Z\.]+)__([Yn])__([0-9]+)\\\\"\)', 'http://\1', $page);
$page = eregi_replace('javascript:genieNavLinkto\(\\\\"([-a-zA-Z0-9_:/\.\?\=&,]*)\\\\"\)', 'http://\1', $page);
$page = ereg_replace('javascript:genieNav\('."'".'([a-zA-Z0-9_]*)'."'".','."'".'([a-zA-Z0-9_]*)'."'".'\)', $url_prefix.'/'.$file_name.'/'.$id.'/\\2/\\1', $page);

//Change the title
$values[] = null;
eregi('<font face="verdana, helvetica, arial, sans-serif" size="1" color="#800080"><b>([-A-Za-z<>\.&; ]*)</b></font>', $page, $values);
$title = strip_tags($values[0]);
if($title) 
	$page = eregi_replace('<title>([A-Za-z ]*)</title>', '<title>'.$title.' - \1</title>', $page);
//else 
//	$page = eregi_replace('<title>([A-Za-z ])</title>', '<title>'.$title.' \1</title>', $page);
//javascript:download4('/usr2/users-v/rschooltoday/se3bin/http://www.rschooltoday.com/school438/genie122/images/files/deca_powerpoint1.pptx','deca_powerpoint1.pptx');
//javascript:download4('/usr2/users-v/rschooltoday/se3bin/../school438/genie122/images/files/deca_powerpoint1.pptx','deca_powerpoint1.pptx');


//replace javascript menus
//$regex = '(aI\("text=([a-zA-Z0-9 ]+);offbgcolor=([A-Z0-9#]+);url=([a-zA-Z0-9/:\=\._]+);(showmenu=[0-9A-Za-z_]+;)?status=[a-zA-Z0-9 ]+;"\);)*';
//$l = ereg($regex, $page, $matches);
/*
//regexp
$regexp = 'aI("text=Our School;offbgcolor=#FFD700;url=http://127.0.0.1/rschool.php/174;showmenu=submenu2_top;status=Our School;");';
$l = preg_match($regexp, $page, $matches);
*/

//preg_match_all
// preg_match_all('$(?:aI\("text=([a-zA-Z0-9 ]+);offbgcolor=([A-Z0-9#]+);url=([a-zA-Z0-9/:\=\._]+);(showmenu=[0-9A-Za-z_]+;)?status=([a-zA-Z0-9 ]+);"\);)$',$page,$matches); 
preg_match_all('$(?:aI\("text=([^;]+);offbgcolor=([A-Z0-9#]+);url=([a-zA-Z0-9/:\=\._]+)(?<!g5plugin);(showmenu=[0-9A-Za-z_]+;)?status=([^;]+);"\);)$',$page,$matches_main); 
$menu = '';
foreach($matches_main[0] as $n => $v)
{
	$menu .= '<a href="'.$matches_main[3][$n].'" alt="'.$matches_main[5][$n].'">'.$matches_main[1][$n].'</a> &nbsp; &nbsp; ';
}
echo '<div id="newmenu" style="font-size: small; text-align: center;">';
echo $menu;
echo '<br />';
preg_match_all('$(?:aI\("text=([^;]+);(?:offbgcolor=;)?offbgcolor=([A-Z0-9#]+);url=([a-zA-Z0-9/:\=\._]+g5plugin);(showmenu=[0-9A-Za-z_]+;)?status=([^;]+);"\);)$',$page,$matches_main); 
$menu = '';
foreach($matches_main[0] as $n => $v)
{
	$menu .= '<a href="'.$matches_main[3][$n].'" alt="'.$matches_main[5][$n].'">'.$matches_main[1][$n].'</a> &nbsp;';
}
echo $menu;
echo '</div><script type="text/javascript">document.getElementById("newmenu").style.display="none";</script>';

echo $page;


//echo $l;
?>
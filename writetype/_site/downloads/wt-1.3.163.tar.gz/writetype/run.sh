#!/bin/bash
python writetype/main.py $@
